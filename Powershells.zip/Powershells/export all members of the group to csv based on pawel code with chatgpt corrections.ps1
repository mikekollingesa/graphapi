# Required for safe encoding
Add-Type -AssemblyName System.Web

# Azure AD App Credentials
$tenantId     = "9a5cacd0-2bef-4dd7-ac5c-7ebe1f54f495"
$clientId     = "28d48667-10ad-4563-93c3-499438dafbab"
$clientSecret = "iUb8Q~v6_N_C41FVhk7kIarErqlH7ulV4FVWCbVq"

# Get access token
$tokenResponse = Invoke-RestMethod -Method POST -Uri "https://login.microsoftonline.com/$tenantId/oauth2/v2.0/token" -Body @{
    client_id     = $clientId
    scope         = "https://graph.microsoft.com/.default"
    client_secret = $clientSecret
    grant_type    = "client_credentials"
}

$accessToken = $tokenResponse.access_token
$headers = @{
    "Authorization" = "Bearer $accessToken"
    "Content-Type"  = "application/json"
}

# Target group
$groupId = "e3fe1293-d3cf-4ffe-9afa-2b63749412c6"

# Step 1: Get email addresses from group members
$userEmails = @()
$url = "https://graph.microsoft.com/beta/groups/$groupId/members?`$top=500&`$select=mail"

do {
    $response = Invoke-RestMethod -Uri $url -Headers $headers -Method GET
    $userEmails += $response.value | Where-Object { $_.mail } | ForEach-Object { $_.mail }
    $url = $response.'@odata.nextLink'
} while ($url)

Write-Host "Found $($userEmails.Count) users with mail addresses"

# Step 2: Query each user by mail using /users?$filter
$userDetails = @()

foreach ($email in $userEmails) {
    $emailTrimmed = $email.Trim().Replace("'", "''")
    $encodedFilter = [System.Web.HttpUtility]::UrlEncode("mail eq '$emailTrimmed'")
    $uri = "https://graph.microsoft.com/v1.0/users?`$filter=$encodedFilter&`$select=userPrincipalName,givenName,surname,displayName,mail,id,externalUserState,externalUserStateChangeDateTime"

    try {
        $res = Invoke-RestMethod -Method GET -Uri $uri -Headers $headers
        if ($res.value.Count -gt 0) {
            $user = $res.value[0]
            $ExtStateChangedOn = $null
            try { $ExtStateChangedOn = [DateTime]::Parse($user.externalUserStateChangeDateTime) } catch {}

            $userDetails += [PSCustomObject]@{
                UPN               = $user.userPrincipalName
                GivenName         = $user.givenName
                Surname           = $user.surname
                DisplayName       = $user.displayName
                Mail              = $user.mail
                Id                = $user.id
                ExtState          = $user.externalUserState
                ExtStateChangedOn = $ExtStateChangedOn
            }
        } else {
            Write-Warning "No user found for ${emailTrimmed}"
        }
    } catch {
        Write-Warning "Lookup failed for ${emailTrimmed}: $($_.Exception.Message)"
    }
}

# Step 3: Output to table
$userDetails | Select-Object Mail, ExtState, ExtStateChangedOn | Format-Table -AutoSize

# Step 4: Export to CSV
$csvPath = "C:\Users\mike.kolling\Downloads\userdetails.csv"
$userDetails | Export-Csv -Path $csvPath -NoTypeInformation -Encoding UTF8
Write-Host "Exported to $csvPath"
