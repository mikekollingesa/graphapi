# ================================
# Configuration
# ================================
$tenantId     = "9a5cacd0-2bef-4dd7-ac5c-7ebe1f54f495"
$clientId     = "28d48667-10ad-4563-93c3-499438dafbab"
$clientSecret = "iUb8Q~v6_N_C41FVhk7kIarErqlH7ulV4FVWCbVq"

# ================================
# Get Access Token
# ================================
Write-Host "Getting access token..." -ForegroundColor Cyan

$tokenResponse = Invoke-RestMethod -Method POST `
    -Uri "https://login.microsoftonline.com/$tenantId/oauth2/v2.0/token" `
    -Body @{
        client_id     = $clientId
        scope         = "https://graph.microsoft.com/.default"
        client_secret = $clientSecret
        grant_type    = "client_credentials"
    }

$token = $tokenResponse.access_token
Write-Host "Access token acquired." -ForegroundColor Green

# ================================
# Decode JWT payload (NO modules)
# ================================
Write-Host "`nDecoding token roles..." -ForegroundColor Cyan

# JWT format: header.payload.signature
$payload = $token.Split('.')[1]

# Fix Base64 padding and URL-safe chars
$payload = $payload.Replace('-', '+').Replace('_', '/')
switch ($payload.Length % 4) {
    2 { $payload += '==' }
    3 { $payload += '=' }
}

# Decode payload JSON
$claimsJson = [Text.Encoding]::UTF8.GetString(
    [Convert]::FromBase64String($payload)
)
$claims = $claimsJson | ConvertFrom-Json

# ================================
# Output roles
# ================================
if ($claims.roles) {
    Write-Host "`nRoles present in access token:" -ForegroundColor Yellow
    $claims.roles | ForEach-Object { Write-Host " - $_" }

    if ($claims.roles -contains "UserAuthenticationMethod.Read.All") {
        Write-Host "`n✅ UserAuthenticationMethod.Read.All IS PRESENT" -ForegroundColor Green
    }
    else {
        Write-Host "`n❌ UserAuthenticationMethod.Read.All IS MISSING" -ForegroundColor Red
    }
}
else {
    Write-Host "`n❌ No 'roles' claim found in token!" -ForegroundColor Red
    Write-Host "This means application permissions are NOT being issued." -ForegroundColor Red
}
