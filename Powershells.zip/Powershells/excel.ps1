# Get all users
$users = Get-MgUser -All

# Select relevant properties
$usersData = $users | Select-Object DisplayName, UserPrincipalName, Mail, JobTitle, Department

# Export to Excel
$excelPath = "$env:USERPROFILE\Documents\entra_users.xlsx"
$usersData | Export-Excel -Path $excelPath -AutoSize
