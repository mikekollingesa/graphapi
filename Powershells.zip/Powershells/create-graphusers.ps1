# Define your schema
$fields = @(
    @{ name = "displayname"; displayName = "Display Name" },
    @{ name = "givenname"; displayName = "Given Name" },
    @{ name = "surname"; displayName = "Surname" },
    @{ name = "mail"; displayName = "Mail" },
    @{ name = "jobtitle"; displayName = "Job Title" },
    @{ name = "userprincipalname"; displayName = "User Principal Name" },
    @{ name = "mobilephone"; displayName = "Mobile Phone" },
    @{ name = "officelocation"; displayName = "Office Location" },
    @{ name = "preferredlanguage"; displayName = "Preferred Language" },
    @{ name = "graphid"; displayName = "Graph API ID" }
)

# Create the Dataverse table
pac dataverse table add --name graphusers --displayname "Graph Users" --description "Imported from Microsoft Graph API"

# Add each column
foreach ($field in $fields) {
    pac dataverse column add `
        --table graphusers `
        --name $field.name `
        --displayname $field.displayName `
        --datatype Text `
        --length 250
}
