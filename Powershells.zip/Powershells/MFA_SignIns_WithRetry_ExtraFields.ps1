# ================================
# Configuration
# ================================
$tenantId     = "9a5cacd0-2bef-4dd7-ac5c-7ebe1f54f495"
$clientId     = "28d48667-10ad-4563-93c3-499438dafbab"
$clientSecret = "iUb8Q~v6_N_C41FVhk7kIarErqlH7ulV4FVWCbVq"

$groupIds = @(
    "0ef5dc15-0d02-4f8c-8ca6-72bcff871524",
    "74bc3edd-5332-42a0-bee4-bdd0b28e019f",
    "cabd421f-0cc4-456a-8519-c1b58ce34566",
    "186b132d-0706-4c05-a128-2a9bd1930bda",
    "11a97d98-c0ed-4309-a5f1-8e0add9f546f",
    "fb28765c-b957-474b-8366-2f9dd5786a24",
    "b82daeb0-2c00-4d53-890b-fdd1a92bd3d3"
)

$csvPath = "C:\Users\mike.kolling\Downloads\MFA_LastSignIns_Extra.csv"

# ================================
# Get Access Token
# ================================
Write-Host "`nGetting access token..."
$tokenResponse = Invoke-RestMethod -Method POST -Uri "https://login.microsoftonline.com/$tenantId/oauth2/v2.0/token" -Body @{
    client_id     = $clientId
    scope         = "https://graph.microsoft.com/.default"
    client_secret = $clientSecret
    grant_type    = "client_credentials"
}
$token = $tokenResponse.access_token
Write-Host "Access token acquired.`n"

# ================================
# Collect members from groups (existing logic)
# ================================
$members = @()
foreach ($gid in $groupIds) {
    $url = "https://graph.microsoft.com/beta/groups/$gid/members?$top=999&`$select=id,displayName,mail,userPrincipalName,jobTitle,department,accountEnabled,externalUserState,externalUserStateChangeDateTime"
    do {
        $resp = Invoke-RestMethod -Uri $url -Headers @{Authorization = "Bearer $token"}
        $filtered = $resp.value | Where-Object { $_.'@odata.type' -eq "#microsoft.graph.user" }
        $members += $filtered
        $url = $resp.'@odata.nextLink'
    } while ($url)
}
$members = $members | Sort-Object id -Unique
Write-Host "Total unique users: $($members.Count)`n"

# ================================
# 👉 Build MFA lookup array (from reports endpoint)
# ================================
$mfaLookup = @{}
try {
    Write-Host "Fetching MFA registration details..."
    $mfaUrl = "https://graph.microsoft.com/beta/reports/credentialUserRegistrationDetails?$top=999"
    do {
        $mfaResp = Invoke-RestMethod -Uri $mfaUrl -Headers @{Authorization = "Bearer $token"}
        foreach ($entry in $mfaResp.value) {
            # Store MFAEnabled (Yes/No) and methods in a hashtable keyed by user id
            $mfaLookup[$entry.id] = [PSCustomObject]@{
                MFAEnabled = if ($entry.isMfaRegistered -eq $true) { "Yes" } else { "No" }
                MFAMethods = ($entry.methodsRegistered -join ";")
            }
        }
        $mfaUrl = $mfaResp.'@odata.nextLink'
    } while ($mfaUrl)
    Write-Host "MFA details fetched for $($mfaLookup.Count) users.`n"
}
catch {
    Write-Warning "MFA fetch failed: $($_.Exception.Message)"
}

# ================================
# Query last sign-in (existing logic) + merge MFA
# ================================
$results = @()
$count = 1
foreach ($m in $members) {
    # Existing sign-in logic
    $signInUrl = "https://graph.microsoft.com/beta/auditLogs/signIns?$filter=userId eq '$($m.id)'&$orderby=createdDateTime desc&$top=1"
    $retried = $false
    $signInData = $null
    while ($true) {
        try {
            $signInData = Invoke-RestMethod -Uri $signInUrl -Headers @{Authorization = "Bearer $token"}
            break
        }
        catch {
            $ex = $_.Exception
            $resp = $ex.Response
            if ($resp -and $resp.StatusCode.value__ -eq 429) {
                $retryAfter = $resp.Headers["Retry-After"]
                if (-not $retryAfter) { $retryAfter = 5 }
                Write-Warning "[$count/$($members.Count)] Throttled for $($m.displayName). Waiting $retryAfter seconds then retry..."
                Start-Sleep -Seconds $retryAfter
                $retried = $true
                continue
            } else {
                Write-Warning "[$count/$($members.Count)] $($m.displayName): error querying signIns - $($ex.Message)"
                break
            }
        }
    }
    $lastSignIn = if ($signInData -and $signInData.value.Count -gt 0) { $signInData.value[0].createdDateTime } else { "" }

    # Look up MFA info if present
    $mfaEnabled = ""
    $mfaMethods = ""
    if ($mfaLookup.ContainsKey($m.id)) {
        $mfaEnabled = $mfaLookup[$m.id].MFAEnabled
        $mfaMethods = $mfaLookup[$m.id].MFAMethods
    }

    Write-Host "[$count/$($members.Count)] $($m.displayName) <$($m.userPrincipalName)> LastSignIn: $lastSignIn MFA: $mfaEnabled"

    $results += [PSCustomObject]@{
        DisplayName                     = $m.displayName
        Mail                            = $m.mail
        UPN                             = $m.userPrincipalName
        OID                             = $m.id
        JobTitle                        = $m.jobTitle
        Department                      = $m.department
        AccountEnabled                  = $m.accountEnabled
        ExternalUserState               = $m.externalUserState
        ExternalUserStateChangeDateTime = $m.externalUserStateChangeDateTime
        LastSignIn                      = $lastSignIn
        MFAEnabled                      = $mfaEnabled
        MFAMethods                      = $mfaMethods
    }

    $count++
    Start-Sleep -Milliseconds 200
}

# ================================
# Export CSV
# ================================
$results | Export-Csv -Path $csvPath -NoTypeInformation
Write-Host "`nExported report with MFA merged to: $csvPath"
