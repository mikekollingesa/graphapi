# ===== MINIMAL MFA ACCESS TEST (DELEGATED) =====
# Purpose: prove whether delegated access to /authentication/methods is allowed

$ErrorActionPreference = "Stop"

# Clean session (avoids 4096 function limit issues)
Get-Module Microsoft.Graph* | Remove-Module -Force -ErrorAction SilentlyContinue

# Import ONLY authentication module
Import-Module Microsoft.Graph.Authentication -Force

# Required delegated scopes
$scopes = @(
  "User.Read.All",
  "UserAuthenticationMethod.Read.All"
)

Write-Host "Signing in to Microsoft Graph (delegated, device code)..." -ForegroundColor Cyan

# Force device-code login (most reliable under CA)
Connect-MgGraph -Scopes $scopes -UseDeviceCode -NoWelcome | Out-Null

$ctx = Get-MgContext
Write-Host "Connected as $($ctx.Account) | Tenant $($ctx.TenantId)" -ForegroundColor Green

# ===== TEST CALL: YOUR OWN USER =====
Write-Host "Testing MFA method access on YOUR account..." -ForegroundColor Cyan

$me = Invoke-MgGraphRequest -Method GET -Uri "https://graph.microsoft.com/v1.0/me"

$methods = Invoke-MgGraphRequest `
  -Method GET `
  -Uri "https://graph.microsoft.com/v1.0/users/$($me.id)/authentication/methods"

Write-Host "SUCCESS: Able to read authentication methods." -ForegroundColor Green
