# ================================
# Configuration
# ================================
$tenantId     = "9a5cacd0-2bef-4dd7-ac5c-7ebe1f54f495"
$clientId     = "28d48667-10ad-4563-93c3-499438dafbab"
$clientSecret = "iUb8Q~v6_N_C41FVhk7kIarErqlH7ulV4FVWCbVq"

# Single Group ID (only)
$groupId = "0ef5dc15-0d02-4f8c-8ca6-72bcff871524"



# ================================
# Token (app-only)
# ================================
$tok = Invoke-RestMethod -Method POST -Uri "https://login.microsoftonline.com/$tenantId/oauth2/v2.0/token" -Body @{
  client_id     = $clientId
  client_secret = $clientSecret
  grant_type    = "client_credentials"
  scope         = "https://graph.microsoft.com/.default"
}
$headers = @{
  Authorization = "Bearer $($tok.access_token)"
  Accept        = "application/json"
}

# ================================
# Helper: Get all pages from a Graph endpoint returning JSON + @odata.nextLink
# ================================
function Get-AllPagesJson([string]$url) {
  $all = @()
  do {
    $resp = Invoke-RestMethod -Headers $headers -Uri $url -Method GET
    if ($resp.value) { $all += $resp.value }
    $url = $resp.'@odata.nextLink'
  } while ($url)
  return $all
}

# ================================
# 1) First 50 users from group
# ================================
$usersUrl = "https://graph.microsoft.com/beta/groups/$groupId/members/microsoft.graph.user?`$top=50&`$select=id,displayName,userPrincipalName"
$users = (Invoke-RestMethod -Headers $headers -Uri $usersUrl -Method GET).value

Write-Host "Users pulled from group: $($users.Count)" -ForegroundColor Green

# ================================
# 2) Full MFA registration report (paged)
# ================================
$reportUrl = "https://graph.microsoft.com/beta/reports/authenticationMethods/userRegistrationDetails?`$top=999"
$reportRows = Get-AllPagesJson $reportUrl

Write-Host "Report rows pulled: $($reportRows.Count)" -ForegroundColor Green

# Index report by user id for fast join
$reportById = @{}
foreach ($r in $reportRows) { $reportById[$r.id] = $r }

# ================================
# 3) Join + output fields
# ================================
$results = foreach ($u in $users) {
  $r = $reportById[$u.id]

  [PSCustomObject]@{
    DisplayName           = $u.displayName
    UserPrincipalName     = $u.userPrincipalName
    UserId                = $u.id
    IsMfaRegistered       = if ($r) { $r.isMfaRegistered } else { $null }
    MfaRegistrationStatus = if ($r) { $r.userPreferredMethodForSecondaryAuthentication; $r.mfaRegistrationStatus } else { "NoReportRow" }
    DefaultMfaMethod      = if ($r) { $r.defaultMfaMethod } else { "" }
    MethodsRegistered     = if ($r -and $r.methodsRegistered) { ($r.methodsRegistered -join ";") } else { "" }
  }
}

$results | Format-Table -AutoSize

# Optional export
# $results | Export-Csv -Path (Join-Path $PSScriptRoot "MFA_RegDetails_GroupFirst50.csv") -NoTypeInformation -Encoding UTF8