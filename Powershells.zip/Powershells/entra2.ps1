Write-Host "Preparing credentials..."

# === CREDENTIALS ===
$tenantId = "9a5cacd0-2bef-4dd7-ac5c-7ebe1f54f495"
$clientId = "8b61fdf1-98ae-4d4a-aeb8-396455123973"
$clientSecret = "HG58Q~tf345EYB_.~VJlz8lc_ym.WdplX7krgbP4"

# === GET TOKEN ===
$tokenUrl = "https://login.microsoftonline.com/$tenantId/oauth2/v2.0/token"
$body = @{
    client_id     = $clientId
    scope         = "https://graph.microsoft.com/.default"
    client_secret = $clientSecret
    grant_type    = "client_credentials"
}

Write-Host "Requesting access token..."
try {
    $response = Invoke-RestMethod -Method Post -Uri $tokenUrl -Body $body
    $token = $response.access_token
    Write-Host "Access token received."
} catch {
    Write-Error "Failed to get token: $_"
    exit
}

# === CALL GRAPH API ===
$headers = @{ Authorization = "Bearer $token" }

Write-Host "Calling Microsoft Graph to fetch users..."
try {
    $users = Invoke-RestMethod -Uri "https://graph.microsoft.com/v1.0/users" -Headers $headers
    Write-Host "Retrieved $($users.value.Count) users."
} catch {
    Write-Error "Failed to fetch users: $_"
    exit
}

# === EXPORT TO FILE ===
$path = "$env:USERPROFILE\Documents\entra_users.json"
try {
    $users.value | ConvertTo-Json -Depth 5 | Out-File $path -Encoding utf8
    Write-Host "Users exported to: $path"
} catch {
    Write-Error "Failed to export to file: $_"
}
