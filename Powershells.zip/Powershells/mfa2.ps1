# === Azure AD App Credentials ===
$tenantId     = "9a5cacd0-2bef-4dd7-ac5c-7ebe1f54f495"
$clientId     = "28d48667-10ad-4563-93c3-499438dafbab"
$clientSecret = "iUb8Q~v6_N_C41FVhk7kIarErqlH7ulV4FVWCbVq"

# === Token Management ===
$global:graphToken = $null
$global:tokenExpiry = (Get-Date).AddMinutes(-1)

function Get-GraphToken {
    if ($null -eq $global:graphToken -or (Get-Date) -gt $global:tokenExpiry) {
        Write-Host "`n🔄 Requesting new Graph token..." -ForegroundColor Cyan
        try {
            $tokenResponse = Invoke-RestMethod -Method POST -Uri "https://login.microsoftonline.com/$tenantId/oauth2/v2.0/token" -Body @{
                client_id     = $clientId
                scope         = "https://graph.microsoft.com/.default"
                client_secret = $clientSecret
                grant_type    = "client_credentials"
            }
            $global:graphToken = $tokenResponse.access_token
            $global:tokenExpiry = (Get-Date).AddSeconds(3500)
            Write-Host "✅ Token retrieved successfully" -ForegroundColor Green
        } catch {
            Write-Host "❌ ERROR retrieving token: $($_.Exception.Message)" -ForegroundColor Red
            throw
        }
    }
    return $global:graphToken
}

# === Fetch Sign-Ins (bulk download) ===
Write-Host "`n📥 Downloading recent sign-ins..." -ForegroundColor Cyan
$signIns = @()
$signInsUrl = "https://graph.microsoft.com/v1.0/auditLogs/signIns?`$top=1000"
$pageCount = 0

do {
    try {
        $pageCount++
        Write-Host "📄 Fetching sign-ins page $pageCount..." -ForegroundColor Gray
        $response = Invoke-RestMethod -Uri $signInsUrl -Headers @{
            Authorization = "Bearer $(Get-GraphToken)"
            "Content-Type" = "application/json"
        }
        $signIns += $response.value
        $signInsUrl = $response.'@odata.nextLink'
    } catch {
        Write-Host "❌ ERROR fetching sign-ins: $($_.Exception.Message)" -ForegroundColor Red
        break
    }
} while ($signInsUrl)

Write-Host "✅ Total sign-ins retrieved: $($signIns.Count)`n" -ForegroundColor Green

# === Fetch Group Members (filter to users only) ===
$groupId = "0ef5dc15-0d02-4f8c-8ca6-72bcff871524"
$groupUrl = "https://graph.microsoft.com/beta/groups/$groupId/members?`$select=id,displayName,mail,userPrincipalName,externalUserState,externalUserStateChangeDateTime"
$members = @()
$pageCount = 0

Write-Host "📥 Downloading group members (users only)..." -ForegroundColor Cyan

do {
    try {
        $pageCount++
        Write-Host "📄 Fetching group members page $pageCount..." -ForegroundColor Gray
        $response = Invoke-RestMethod -Uri $groupUrl -Headers @{
            Authorization = "Bearer $(Get-GraphToken)"
            "Content-Type" = "application/json"
        }

        $userSubset = $response.value | Where-Object { $_.'@odata.type' -eq '#microsoft.graph.user' }
        Write-Host "   → Found $($userSubset.Count) users on this page" -ForegroundColor Yellow
        $members += $userSubset
        $groupUrl = $response.'@odata.nextLink'
    } catch {
        Write-Host "❌ ERROR fetching group members: $($_.Exception.Message)" -ForegroundColor Red
        break
    }
} while ($groupUrl)

Write-Host "✅ Total user members retrieved: $($members.Count)`n" -ForegroundColor Green

# === Analyze MFA Usage ===
$results = @()
$count = 0
$total = $members.Count
$startTime = Get-Date

Write-Host "🔍 Analyzing MFA usage for $total users..." -ForegroundColor Cyan

foreach ($user in $members) {
    $count++
    Write-Host "-> [$count/$total] $($user.displayName) $($user.userPrincipalName)" -ForegroundColor Yellow

    $recentSignIn = $signIns | Where-Object { $_.userId -eq $user.id } | Sort-Object createdDateTime -Descending | Select-Object -First 1

    $mfaStatus = "NoSignIns"
    $mfaDetails = ""
    $mfaError = ""

    if ($recentSignIn) {
        try {
            $details = $recentSignIn.status.additionalDetails
            $mfaDetails = $details

            if ($details -match "MFA requirement satisfied|MFA completed") {
                $mfaStatus = "Yes"
            } elseif ($details -match "needs to perform multi-factor") {
                $mfaStatus = "RequiredButNotCompleted"
            } else {
                $mfaStatus = "No"
            }
        } catch {
            $mfaStatus = "Error"
            $mfaError = $_.Exception.Message
        }
    }

    $results += [PSCustomObject]@{
        DisplayName                    = $user.displayName
        Mail                           = $user.mail
        UPN                            = $user.userPrincipalName
        OID                            = $user.id
        MFAEnabled                     = $mfaStatus
        MFAError                       = $mfaError
        MFADetails                     = $mfaDetails
        ExternalUserState              = $user.externalUserState
        ExternalUserStateChangeDateTime = $user.externalUserStateChangeDateTime
    }
}

$endTime = Get-Date
$elapsed = ($endTime - $startTime).TotalMinutes
Write-Host "`n⏱️  MFA analysis complete in $([math]::Round($elapsed,2)) minutes." -ForegroundColor Green

# === Export Results ===
$csvPath = "C:\Users\mike.kolling\Downloads\APL_BLUEDOCS_PRD_group_members_with_MFA_debug.csv"
$results | Export-Csv -Path $csvPath -NoTypeInformation
Write-Host "📄 Exported to: $csvPath" -ForegroundColor Cyan
