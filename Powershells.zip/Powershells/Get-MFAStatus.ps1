# ================================
# Configuration
# ================================
$tenantId     = "9a5cacd0-2bef-4dd7-ac5c-7ebe1f54f495"
$clientId     = "28d48667-10ad-4563-93c3-499438dafbab"
$clientSecret = "iUb8Q~v6_N_C41FVhk7kIarErqlH7ulV4FVWCbVq"

# List of Group IDs to process
$groupIds = @(
    "0ef5dc15-0d02-4f8c-8ca6-72bcff871524",
    "74bc3edd-5332-42a0-bee4-bdd0b28e019f",
    "cabd421f-0cc4-456a-8519-c1b58ce34566",
    "186b132d-0706-4c05-a128-2a9bd1930bda",
    "11a97d98-c0ed-4309-a5f1-8e0add9f546f",
    "fb28765c-b957-474b-8366-2f9dd5786a24",
    "b82daeb0-2c00-4d53-890b-fdd1a92bd3d3"
)

# Output path for CSV
$csvPath = "C:\Users\mike.kolling\Downloads\MFA_Report_AllGroups.csv"

# ================================
# Get access token
# ================================
Write-Host "`nGetting access token..."
$tokenResponse = Invoke-RestMethod -Method POST -Uri "https://login.microsoftonline.com/$tenantId/oauth2/v2.0/token" -Body @{
    client_id     = $clientId
    scope         = "https://graph.microsoft.com/.default"
    client_secret = $clientSecret
    grant_type    = "client_credentials"
}

if (-not $tokenResponse.access_token) {
    Write-Error "Failed to obtain access token"
    exit 1
}
$token = $tokenResponse.access_token
Write-Host "Access token acquired.`n"

# ================================
# Collect all members from all groups
# ================================
$members = @()

foreach ($groupId in $groupIds) {
    $groupUrl = "https://graph.microsoft.com/beta/groups/$groupId/members?`$select=id,displayName,mail,userPrincipalName,externalUserState,externalUserStateChangeDateTime"
    $page = 1

    do {
        Write-Host "Fetching page $page from group $groupId"
        try {
            $response = Invoke-RestMethod -Uri $groupUrl -Headers @{
                Authorization = "Bearer $token"
                "Content-Type" = "application/json"
            }
        }
        catch {
            Write-Error "Error retrieving group members for $groupId. Details: $($_)"
            break
        }

        # Only keep users (skip service principals or other objects)
        $filtered = $response.value | Where-Object { $_.'@odata.type' -eq "#microsoft.graph.user" }
        $members += $filtered

        $groupUrl = $response.'@odata.nextLink'
        $page++
    } while ($groupUrl)
}

# Deduplicate users by their Object ID
$members = $members | Sort-Object id -Unique
Write-Host "`nTotal unique users retrieved across all groups: $($members.Count)`n"

# ================================
# Check MFA methods for each user
# ================================
$results = @()
$i = 1
$total = $members.Count

foreach ($user in $members) {
    Write-Host "[$i/$total] Checking MFA for $($user.displayName) <$($user.userPrincipalName)>"
    $mfaStatus = "Unknown"
    $mfaError = ""

    try {
        $authUrl = "https://graph.microsoft.com/beta/users/$($user.id)/authentication/methods"
        $authMethods = Invoke-RestMethod -Uri $authUrl -Headers @{
            Authorization = "Bearer $token"
            "Content-Type" = "application/json"
        }

        $mfaMethods = $authMethods.value | Where-Object {
            $_.'@odata.type' -in @(
                "#microsoft.graph.phoneAuthenticationMethod",
                "#microsoft.graph.microsoftAuthenticatorAuthenticationMethod",
                "#microsoft.graph.fido2AuthenticationMethod",
                "#microsoft.graph.softwareOathAuthenticationMethod"
            )
        }

        $mfaStatus = if ($mfaMethods.Count -gt 0) { "Yes" } else { "No" }
    }
    catch {
        $mfaStatus = "Error"
        $mfaError = $_.Exception.Message
    }

    $results += [PSCustomObject]@{
        DisplayName                     = $user.displayName
        Mail                            = $user.mail
        UPN                             = $user.userPrincipalName
        OID                             = $user.id
        MFAEnabled                      = $mfaStatus
        MFAError                        = $mfaError
        ExternalUserState               = $user.externalUserState
        ExternalUserStateChangeDateTime = $user.externalUserStateChangeDateTime
    }

    $i++
}

# ================================
# Export to CSV
# ================================
try {
    $results | Export-Csv -Path $csvPath -NoTypeInformation
    Write-Host "`nExported MFA report to: $csvPath"
}
catch {
    Write-Error "Failed to export CSV: $_"
}
