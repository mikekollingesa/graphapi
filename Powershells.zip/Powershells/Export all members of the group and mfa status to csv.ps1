# Azure AD App Credentials
$tenantId     = "9a5cacd0-2bef-4dd7-ac5c-7ebe1f54f495"
$clientId     = "28d48667-10ad-4563-93c3-499438dafbab"
$clientSecret = "iUb8Q~v6_N_C41FVhk7kIarErqlH7ulV4FVWCbVq"

# Get access token
$tokenResponse = Invoke-RestMethod -Method POST -Uri "https://login.microsoftonline.com/$tenantId/oauth2/v2.0/token" -Body @{
    client_id     = $clientId
    scope         = "https://graph.microsoft.com/.default"
    client_secret = $clientSecret
    grant_type    = "client_credentials"
}
$token = $tokenResponse.access_token

# Group ID
# New One     0ef5dc15-0d02-4f8c-8ca6-72bcff871524
# Old One    e3fe1293-d3cf-4ffe-9afa-2b63749412c6
$groupId = "0ef5dc15-0d02-4f8c-8ca6-72bcff871524"

# Initial API request URL – ADDING externalUserState fields
$baseUrl = "https://graph.microsoft.com/beta/groups/$groupId/members/microsoft.graph.user?`$select=id,displayName,mail,userPrincipalName,externalUserState,externalUserStateChangeDateTime"

$allUsers = @()

do {
    try {
        $response = Invoke-RestMethod -Uri $baseUrl -Headers @{
            Authorization = "Bearer $token"
            "Content-Type" = "application/json"
        }
    } catch {
        Write-Host "❌ Failed to retrieve group members: $($_.Exception.Message)"
        break
    }

    foreach ($user in $response.value) {
        $mfaStatus = "Unavailable"
        $mfaError  = ""

        try {
            $authUrl = "https://graph.microsoft.com/beta/users/$($user.id)/authentication/methods"
            $authMethods = Invoke-RestMethod -Uri $authUrl -Headers @{
                Authorization = "Bearer $token"
                "Content-Type" = "application/json"
            }

            $mfaMethods = $authMethods.value | Where-Object {
                $_.'@odata.type' -in @(
                    "#microsoft.graph.phoneAuthenticationMethod",
                    "#microsoft.graph.microsoftAuthenticatorAuthenticationMethod",
                    "#microsoft.graph.fido2AuthenticationMethod",
                    "#microsoft.graph.softwareOathAuthenticationMethod"
                )
            }

            $mfaStatus = if ($mfaMethods.Count -gt 0) { "Yes" } else { "No" }

        } catch {
            $mfaStatus = "Error"
            $mfaError  = $_.Exception.Message
        }

        $allUsers += [PSCustomObject]@{
            DisplayName                    = $user.displayName
            Mail                           = $user.mail
            UPN                            = $user.userPrincipalName
            OID                            = $user.id
            MFAEnabled                     = $mfaStatus
            MFAError                       = $mfaError
            ExternalUserState              = $user.externalUserState
            ExternalUserStateChangeDateTime = $user.externalUserStateChangeDateTime
        }
    }

    $baseUrl = $response.'@odata.nextLink'

} while ($baseUrl)

# Export to CSV
$csvPath = "C:\Users\mike.kolling\Downloads\APL_BLUEDOCS_PRD_group_members_with_MFA.csv"
$allUsers | Export-Csv -Path $csvPath -NoTypeInformation

Write-Host "✅ Export complete with error reporting: $csvPath"
