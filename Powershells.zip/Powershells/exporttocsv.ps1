# Install module if you haven't
# Install-Module -Name Microsoft.PowerPlatform.Cds.Client -AllowClobber -Force

Import-Module Microsoft.PowerPlatform.Cds.Client

# Connect interactively (opens login prompt)
$service = Connect-CdsOnline -InteractiveMode

# Set entity and field names
$entityLogicalName = "cap_memberstaterepresentative"  # your MSR logical name
$fieldName = "cap_email1"  # your email field name

# Retrieve all records (you can add filtering if needed)
$records = Get-CdsRecords -EntityLogicalName $entityLogicalName -AllRows

# Select only email field, exclude nulls
$emails = $records | Where-Object { $_.$fieldName } | Select-Object @{Name='Email';Expression={$_.($fieldName)}}

# Export to CSV (choose your path)
$exportPath = "C:\temp\msr_emails.csv"
if (-not (Test-Path (Split-Path $exportPath))) {
    New-Item -ItemType Directory -Path (Split-Path $exportPath) | Out-Null
}

$emails | Export-Csv -Path $exportPath -NoTypeInformation

Write-Host "Exported $($emails.Count) emails to $exportPath"
