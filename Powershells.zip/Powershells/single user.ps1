# ================================
# Configuration
# ================================
$tenantId     = "9a5cacd0-2bef-4dd7-ac5c-7ebe1f54f495"
$clientId     = "28d48667-10ad-4563-93c3-499438dafbab"
$clientSecret = "iUb8Q~v6_N_C41FVhk7kIarErqlH7ulV4FVWCbVq"

# Group IDs
$groupIds = @(
    "0ef5dc15-0d02-4f8c-8ca6-72bcff871524",
    "74bc3edd-5332-42a0-bee4-bdd0b28e019f",
    "cabd421f-0cc4-456a-8519-c1b58ce34566",
    "186b132d-0706-4c05-a128-2a9bd1930bda",
    "11a97d98-c0ed-4309-a5f1-8e0add9f546f",
    "fb28765c-b957-474b-8366-2f9dd5786a24",
    "b82daeb0-2c00-4d53-890b-fdd1a92bd3d3"
)



# Only process this specific user
$targetUPN = 'mark.sokolowski@ngm.gov.hu'

# Output path
$csvPath = "C:\Users\mike.kolling\Downloads\MFA_LastSignIns.csv"

# ================================
# Get Access Token
# ================================
Write-Host "`nGetting access token..."
$tokenResponse = Invoke-RestMethod -Method POST -Uri "https://login.microsoftonline.com/$tenantId/oauth2/v2.0/token" -Body @{
    client_id     = $clientId
    scope         = "https://graph.microsoft.com/.default"
    client_secret = $clientSecret
    grant_type    = "client_credentials"
}
$token = $tokenResponse.access_token
Write-Host "Access token acquired.`n"

# ================================
# Collect members from groups
# ================================
$members = @()
foreach ($gid in $groupIds) {
    $url = "https://graph.microsoft.com/beta/groups/$gid/members?$top=999"
    do {
        $resp = Invoke-RestMethod -Uri $url -Headers @{Authorization = "Bearer $token"}
        $filtered = $resp.value | Where-Object { $_.'@odata.type' -eq "#microsoft.graph.user" }
        $members += $filtered
        $url = $resp.'@odata.nextLink'
    } while ($url)
}
$members = $members | Sort-Object id -Unique

# Filter to the single target user (case-insensitive)
$members = $members | Where-Object { $_.userPrincipalName -ieq $targetUPN }

if (-not $members -or $members.Count -eq 0) {
    Write-Warning "Target user '$targetUPN' was not found in the provided groups."
    return
}

Write-Host "Processing target user only: $($members[0].displayName) <$($members[0].userPrincipalName)>`n"

# ================================
# Query last sign-in with retry logic
# ================================
$results = @()
$count = 1
foreach ($m in $members) {
    $signInUrl = "https://graph.microsoft.com/beta/auditLogs/signIns?$filter=userId eq '$($m.id)'&$orderby=createdDateTime desc&$top=1"
    $retried = $false
    $signInData = $null

    while ($true) {
        try {
            $signInData = Invoke-RestMethod -Uri $signInUrl -Headers @{Authorization = "Bearer $token"}
            break
        }
        catch {
            $ex = $_.Exception
            $resp = $ex.Response
            if ($resp -and $resp.StatusCode.value__ -eq 429) {
                # Get Retry-After header if present
                $retryAfter = $resp.Headers["Retry-After"]
                if (-not $retryAfter) { $retryAfter = 5 } # default fallback
                Write-Warning "[$count/$($members.Count)] Throttled for $($m.displayName). Waiting $retryAfter seconds then retry..."
                Start-Sleep -Seconds $retryAfter
                $retried = $true
                continue
            }
            else {
                Write-Warning "[$count/$($members.Count)] $($m.displayName): error querying signIns - $($ex.Message)"
                break
            }
        }
    }

    $lastSignIn = ""
    if ($signInData -and $signInData.value.Count -gt 0) {
        $lastSignIn = $signInData.value[0].createdDateTime
        Write-Host "[$count/$($members.Count)] $($m.displayName) <$($m.userPrincipalName)> LastSignIn: $lastSignIn"
    }
    else {
        if (-not $retried) {
            Write-Host "[$count/$($members.Count)] $($m.displayName) <$($m.userPrincipalName)> No sign-in data"
        }
    }

    $results += [PSCustomObject]@{
        DisplayName = $m.displayName
        UPN         = $m.userPrincipalName
        OID         = $m.id
        LastSignIn  = $lastSignIn
    }

    $count++
    Start-Sleep -Milliseconds 200 # slight delay to reduce throttling
}

# ================================
# Export CSV
# ================================
$results | Export-Csv -Path $csvPath -NoTypeInformation
Write-Host "`nExported MFA/SignIn report to: $csvPath"
