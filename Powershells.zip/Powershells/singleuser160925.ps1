# =====================================================================
# Single-user RESOLVE + ENTRA DETAILS (beta-first) + MFA SUMMARY (PS 5.1)
# - Resolves user by external email (mail/otherMails/identities)
# - Gets rich user fields via /beta (with v1.0 fallbacks)
# - Lists DIRECT/TRANSITIVE membership for provided groups
# - Shows last interactive sign-in (auditLogs v1.0) + signInActivity rollup
# - Attempts MFA registration details (Reports v1.0) with robust filters
# - Lists authentication methods (requires UserAuthenticationMethod.Read.All)
#
# Required APPLICATION permissions (admin consent):
#   - Directory.Read.All OR User.Read.All
#   - Group.Read.All
#   - AuditLog.Read.All
#   - Reports.Read.All
#   - (optional but recommended) UserAuthenticationMethod.Read.All
# =====================================================================

# ---------- CONFIG ----------
$tenantId     = "9a5cacd0-2bef-4dd7-ac5c-7ebe1f54f495"
$clientId     = "28d48667-10ad-4563-93c3-499438dafbab"
$clientSecret = "iUb8Q~v6_N_C41FVhk7kIarErqlH7ulV4FVWCbVq"

# Target user (external email you want to resolve)
$targetEmail  = 'p.baldauf@aiic.net'

# Group IDs to check
$groupIds = @(
  "0ef5dc15-0d02-4f8c-8ca6-72bcff871524",
  "74bc3edd-5332-42a0-bee4-bdd0b28e019f",
  "cabd421f-0cc4-456a-8519-c1b58ce34566",
  "186b132d-0706-4c05-a128-2a9bd1930bda",
  "11a97d98-c0ed-4309-a5f1-8e0add9f546f",
  "fb28765c-b957-474b-8366-2f9dd5786a24",
  "b82daeb0-2c00-4d53-890b-fdd1a92bd3d3"
)

# ---------- TOKEN ----------
Write-Host "`nGetting access token..."
$tokenResponse = Invoke-RestMethod -Method POST -Uri "https://login.microsoftonline.com/$tenantId/oauth2/v2.0/token" -Body @{
  client_id     = $clientId
  scope         = "https://graph.microsoft.com/.default"
  client_secret = $clientSecret
  grant_type    = "client_credentials"
}
$token = $tokenResponse.access_token
$auth  = @{ Authorization = "Bearer $token" }
Write-Host "Access token acquired.`n"

# ---------- HELPERS ----------
function Invoke-Graph {
  param([Parameter(Mandatory)][string] $Uri)
  Invoke-RestMethod -Method GET -Uri $Uri -Headers $auth -ErrorAction Stop
}
function Try-InvokeGraph {
  param([string] $Uri)
  try { Invoke-Graph $Uri } catch {
    Write-Warning "Graph call failed: $($_.Exception.Message)`n  URI: $Uri"
    $null
  }
}
function Get-DefaultTenantDomain {
  $org = Invoke-Graph "https://graph.microsoft.com/v1.0/organization?`$select=verifiedDomains"
  $domains = $org.value[0].verifiedDomains
  $default = ($domains | Where-Object { $_.isDefault -eq $true }).name
  if (-not $default) { $default = ($domains | Where-Object { $_.isInitial -eq $true }).name }
  $default
}
function Resolve-User {
  param([string] $email)

  # 1) direct UPN
  try {
    $u = Invoke-Graph "https://graph.microsoft.com/v1.0/users/$email?`$select=id,displayName,userPrincipalName,mail,otherMails,userType"
    if ($u) { return $u }
  } catch { }

  # 2) mail eq '{email}'
  try {
    $r = Invoke-Graph "https://graph.microsoft.com/v1.0/users?`$select=id,displayName,userPrincipalName,mail,otherMails,userType&`$filter=mail eq '$email'"
    if ($r.value.Count -gt 0) { return $r.value[0] }
  } catch { }

  # 3) otherMails contains '{email}'
  try {
    $r = Invoke-Graph "https://graph.microsoft.com/v1.0/users?`$select=id,displayName,userPrincipalName,mail,otherMails,userType&`$filter=otherMails/any(m:m eq '$email')"
    if ($r.value.Count -gt 0) { return $r.value[0] }
  } catch { }

  # 4) identities issuerAssignedId == email (beta) as fallback
  try {
    $issuer = Get-DefaultTenantDomain
    $r = Invoke-Graph "https://graph.microsoft.com/beta/users?`$select=id,displayName,userPrincipalName,mail,otherMails,userType&`$filter=identities/any(c:c/issuerAssignedId eq '$email' and c/issuer eq '$issuer')"
    if ($r.value.Count -gt 0) { return $r.value[0] }
  } catch { }

  $null
}

function Get-UserDetails {
  param([string] $userId)

  # First: /beta with broad select (includes extensionAttributes)
  $selBeta = @(
    "id","displayName","givenName","surname","userPrincipalName","userType",
    "mail","otherMails","accountEnabled","createdDateTime",
    "department","jobTitle","businessPhones","mobilePhone","preferredLanguage",
    "streetAddress","city","state","country","postalCode","officeLocation","usageLocation",
    "employeeId","employeeType",
    "onPremisesSyncEnabled","onPremisesImmutableId","onPremisesDomainName",
    "onPremisesSamAccountName","onPremisesDistinguishedName","onPremisesSecurityIdentifier",
    "onPremisesExtensionAttributes","extensionAttributes",
    "signInSessionsValidFromDateTime","lastPasswordChangeDateTime",
    "externalUserState","externalUserStateChangeDateTime",
    "identities","assignedLicenses","assignedPlans"
  ) -join ","

  $u1 = Try-InvokeGraph "https://graph.microsoft.com/beta/users/$userId?`$select=$selBeta"
  if ($u1) { return $u1 }

  # Fallback A: v1.0 filter by id (some tenants 400 on /users/{id}?$select=...)
  $selV1 = @(
    "id","displayName","givenName","surname","userPrincipalName","userType",
    "mail","otherMails","accountEnabled","createdDateTime",
    "department","jobTitle","businessPhones","mobilePhone","preferredLanguage",
    "streetAddress","city","state","country","postalCode","officeLocation","usageLocation",
    "employeeId","employeeType",
    "onPremisesSyncEnabled","onPremisesImmutableId","onPremisesDomainName",
    "onPremisesSamAccountName","onPremisesDistinguishedName","onPremisesSecurityIdentifier",
    "onPremisesExtensionAttributes",
    "signInSessionsValidFromDateTime","lastPasswordChangeDateTime",
    "externalUserState","externalUserStateChangeDateTime",
    "identities","assignedLicenses","assignedPlans"
  ) -join ","

  $u2 = Try-InvokeGraph "https://graph.microsoft.com/v1.0/users?`$filter=id eq '$userId'&`$select=$selV1"
  if ($u2 -and $u2.value -and $u2.value.Count -gt 0) { return $u2.value[0] }

  # Fallback B: v1.0 with minimal fields by id (no $select)
  $u3 = Try-InvokeGraph "https://graph.microsoft.com/v1.0/users/$userId"
  return $u3
}

function Get-Manager {
  param([string] $userId)
  Try-InvokeGraph "https://graph.microsoft.com/v1.0/users/$userId/manager?`$select=id,displayName,userPrincipalName,mail"
}

function Get-AuthMethods {
  param([string] $userId)
  # Requires: UserAuthenticationMethod.Read.All (Application)
  Try-InvokeGraph "https://graph.microsoft.com/v1.0/users/$userId/authentication/methods"
}

function Get-UserRegDetails {
  param([string] $userId, [string] $userPrincipalName, [string] $mail, [object] $otherMails)

  # 1) by userId
  $r1 = Try-InvokeGraph "https://graph.microsoft.com/v1.0/reports/authenticationMethods/userRegistrationDetails?`$filter=userId eq '$userId'"
  if ($r1 -and $r1.value -and $r1.value.Count -gt 0) { return $r1 }

  # 2) by full UPN (may include #EXT#)
  if ($userPrincipalName) {
    $upn = $userPrincipalName.Replace("'","''")
    $r2 = Try-InvokeGraph "https://graph.microsoft.com/v1.0/reports/authenticationMethods/userRegistrationDetails?`$filter=userPrincipalName eq '$upn'"
    if ($r2 -and $r2.value -and $r2.value.Count -gt 0) { return $r2 }

    # 3) by UPN prefix before '#EXT#'
    if ($upn -match "^(.*)#EXT#@") {
      $prefix = $Matches[1]
      $prefixEsc = $prefix.Replace("'","''")
      # contains() is supported on many reports endpoints; try both contains and startswith
      $r3a = Try-InvokeGraph "https://graph.microsoft.com/v1.0/reports/authenticationMethods/userRegistrationDetails?`$filter=contains(userPrincipalName,'$prefixEsc')"
      if ($r3a -and $r3a.value -and $r3a.value.Count -gt 0) { return $r3a }
      $r3b = Try-InvokeGraph "https://graph.microsoft.com/v1.0/reports/authenticationMethods/userRegistrationDetails?`$filter=startswith(userPrincipalName,'$prefixEsc')"
      if ($r3b -and $r3b.value -and $r3b.value.Count -gt 0) { return $r3b }
    }
  }

  # 4) by mail
  if ($mail) {
    $mailEsc = $mail.Replace("'","''")
    $r4 = Try-InvokeGraph "https://graph.microsoft.com/v1.0/reports/authenticationMethods/userRegistrationDetails?`$filter=mail eq '$mailEsc'"
    if ($r4 -and $r4.value -and $r4.value.Count -gt 0) { return $r4 }
  }

  # 5) by otherMails (iterate)
  if ($otherMails) {
    foreach ($em in $otherMails) {
      if (-not $em) { continue }
      $emEsc = $em.Replace("'","''")
      $r5 = Try-InvokeGraph "https://graph.microsoft.com/v1.0/reports/authenticationMethods/userRegistrationDetails?`$filter=mail eq '$emEsc' or userPrincipalName eq '$emEsc'"
      if ($r5 -and $r5.value -and $r5.value.Count -gt 0) { return $r5 }
    }
  }

  $null
}

function Get-LastInteractiveSignInV1 {
  param([string] $userId)

  $url = "https://graph.microsoft.com/v1.0/auditLogs/signIns?`$filter=userId eq '$userId'&`$orderby=createdDateTime desc&`$top=1"
  $attempts = 0
  while ($attempts -lt 4) {
    try {
      $resp = Invoke-RestMethod -Method GET -Uri $url -Headers $auth -ErrorAction Stop
      if ($resp.value.Count -gt 0) { return $resp.value[0] }
      return $null
    } catch {
      $attempts++
      $status = $null
      try { $status = $_.Exception.Response.StatusCode.value__ } catch { }
      if ($status -eq 429) {
        $retryAfter = $_.Exception.Response.Headers["Retry-After"]; if (-not $retryAfter) { $retryAfter = 5 }
        Write-Warning "Throttled (429). Waiting $retryAfter s then retry ($attempts/3)..."
        Start-Sleep -Seconds $retryAfter
      } else {
        Write-Warning "v1.0 signIns query failed: $($_.Exception.Message)"
        return $null
      }
    }
  }
  $null
}

# ---------- RESOLVE USER ----------
$user = Resolve-User -email $targetEmail
if (-not $user) {
  Write-Warning "Could not resolve a user for '$targetEmail' in your tenant."
  return
}
Write-Host "Resolved user:`n  Name: $($user.displayName)`n  UPN : $($user.userPrincipalName)`n  Type: $($user.userType)`n  ID  : $($user.id)`n" -ForegroundColor Cyan

# ---------- ENTRA USER DETAILS ----------
$details = Get-UserDetails -userId $user.id
$manager = Get-Manager -userId $user.id
if ($manager) { $details | Add-Member -NotePropertyName manager -NotePropertyValue $manager -Force }

Write-Host "Core Entra user details:" -ForegroundColor Cyan
if ($details) { $details | ConvertTo-Json -Depth 7 } else { Write-Host "  (not returned)" }

# ---------- DIRECT MEMBERSHIP ----------
$directHits = @()
foreach ($gid in $groupIds) {
  $uri = "https://graph.microsoft.com/v1.0/groups/$gid/members?`$select=id,userPrincipalName&`$top=999"
  do {
    $resp = Try-InvokeGraph $uri
    if (-not $resp) { break }
    if ($resp.value | Where-Object { $_.id -eq $user.id }) { $directHits += $gid; break }
    $uri = $resp.'@odata.nextLink'
  } while ($uri)
}
if ($directHits.Count) {
  Write-Host "`nDIRECT membership found in group(s): $($directHits -join ', ')" -ForegroundColor Green
} else {
  Write-Host "`nNo DIRECT membership found in provided groups." -ForegroundColor Yellow
}

# ---------- TRANSITIVE MEMBERSHIP ----------
$tm = Try-InvokeGraph "https://graph.microsoft.com/v1.0/users/$($user.id)/transitiveMemberOf?`$select=id,displayName"
if ($tm) {
  $tmIds = $tm.value.id
  $transitiveHits = $groupIds | Where-Object { $tmIds -contains $_ }
  if ($transitiveHits) {
    Write-Host "TRANSITIVE membership found in group(s): $($transitiveHits -join ', ')" -ForegroundColor Green
  } else {
    Write-Host "No TRANSITIVE membership found in provided groups." -ForegroundColor Yellow
  }
}

# ---------- LAST SIGN-IN ----------
$siV1 = Get-LastInteractiveSignInV1 -userId $user.id
if ($siV1) {
  Write-Host "`nLast sign-in (v1.0 signIns):" -ForegroundColor Cyan
  Write-Host "  Time       : $($siV1.createdDateTime)"
  Write-Host "  IP         : $($siV1.ipAddress)"
  Write-Host "  App        : $($siV1.appDisplayName)"
  Write-Host "  StatusCode : $($siV1.status.errorCode)"
} else {
  Write-Host "`nNo records from v1.0 signIns."
}

try {
  $urlAct = "https://graph.microsoft.com/v1.0/users/$($user.id)?`$select=displayName,userPrincipalName,signInActivity"
  $act = Invoke-Graph $urlAct
  if ($act.signInActivity) {
    Write-Host "`nsignInActivity (rollup on user):" -ForegroundColor Cyan
    Write-Host "  lastSignInDateTime              : $($act.signInActivity.lastSignInDateTime)"
    Write-Host "  lastNonInteractiveSignInDateTime: $($act.signInActivity.lastNonInteractiveSignInDateTime)"
    Write-Host "  lastSuccessfulSignInDateTime    : $($act.signInActivity.lastSuccessfulSignInDateTime)"
    Write-Host "  lastSignInRequestId             : $($act.signInActivity.lastSignInRequestId)"
  } else {
    Write-Host "`nNo signInActivity available for this user."
  }
} catch {
  Write-Warning "signInActivity query failed: $($_.Exception.Message)"
}

# ---------- AUTH METHODS + REGISTRATION ----------
$authMethods = Get-AuthMethods -userId $user.id
if (-not $authMethods) {
  Write-Warning "authentication/methods returned nothing. If you also saw 403, grant Application permission: UserAuthenticationMethod.Read.All (admin consent)."
}

$methodTypes = @()
if ($authMethods -and $authMethods.value) {
  foreach ($m in $authMethods.value) {
    $t = $null
    $typeProp = $m.PSObject.Properties['@odata.type']
    if ($typeProp) { $t = $typeProp.Value }

    switch -Wildcard ($t) {
      "*microsoftAuthenticatorAuthenticationMethod" { $methodTypes += "Microsoft Authenticator" }
      "*softwareOathAuthenticationMethod"           { $methodTypes += "Software OATH" }
      "*phoneAuthenticationMethod" {
        $hasPhoneType = ($m.PSObject.Properties.Name -contains 'phoneType') -and $m.phoneType
        if ($hasPhoneType) { $kind = $m.phoneType } else { $kind = "phone" }
        $methodTypes += ("Phone ({0})" -f $kind)
      }
      "*emailAuthenticationMethod"                  { $methodTypes += "Email OTP" }
      "*temporaryAccessPassAuthenticationMethod"    { $methodTypes += "Temporary Access Pass" }
      "*fido2AuthenticationMethod"                  { $methodTypes += "FIDO2 security key" }
      "*windowsHelloForBusinessAuthenticationMethod"{ $methodTypes += "Windows Hello for Business" }
      "*passwordAuthenticationMethod"               { $methodTypes += "Password (basic)" }
      default {
        if ($t) { $methodTypes += ($t -replace '^.*\.', '') }
      }
    }
  }
}
$methodTypes = $methodTypes | Select-Object -Unique

$regResp = Get-UserRegDetails -userId $user.id -userPrincipalName $user.userPrincipalName -mail $user.mail -otherMails $user.otherMails
$reg = $null
if ($regResp -and $regResp.value) { $reg = $regResp.value[0] }

$mfaCapable    = $false
$mfaRegistered = $false
$registeredPrimaryMethods = @()

if ($reg) {
  if ($reg.PSObject.Properties.Name -contains 'isMfaCapable')    { $mfaCapable    = [bool]$reg.isMfaCapable }
  if ($reg.PSObject.Properties.Name -contains 'isMfaRegistered') { $mfaRegistered = [bool]$reg.isMfaRegistered }
  if ($reg.PSObject.Properties.Name -contains 'defaultMfaMethod' -and $reg.defaultMfaMethod) {
    $registeredPrimaryMethods += $reg.defaultMfaMethod
  }
  if ($reg.PSObject.Properties.Name -contains 'methodsRegistered' -and $reg.methodsRegistered) {
    $registeredPrimaryMethods += $reg.methodsRegistered
  }
  $registeredPrimaryMethods = $registeredPrimaryMethods | Where-Object { $_ } | Select-Object -Unique
}

Write-Host "`nAuthentication methods (registered):" -ForegroundColor Cyan
if ($methodTypes.Count -gt 0) {
  $methodTypes | ForEach-Object { Write-Host "  - $_" }
} else {
  Write-Host "  (none returned)"
}

Write-Host "`nRegistration details (Reports):" -ForegroundColor Cyan
if ($reg) {
  if ($reg.PSObject.Properties.Name -contains 'userDisplayName')   { Write-Host ("  userDisplayName : {0}" -f $reg.userDisplayName) }
  if ($reg.PSObject.Properties.Name -contains 'userPrincipalName') { Write-Host ("  userPrincipalName: {0}" -f $reg.userPrincipalName) }
  Write-Host ("  isMfaCapable    : {0}" -f $mfaCapable)
  Write-Host ("  isMfaRegistered : {0}" -f $mfaRegistered)
  if ($registeredPrimaryMethods.Count -gt 0) {
    Write-Host ("  methodsRegistered: {0}" -f ($registeredPrimaryMethods -join ", "))
  }
} else {
  Write-Host "  (no userRegistrationDetails record found)"
}

Write-Host "`nMFA SUMMARY:" -ForegroundColor Cyan
Write-Host ("  Capable   : {0}" -f $mfaCapable)
Write-Host ("  Registered: {0}" -f $mfaRegistered)
if ($methodTypes.Count -gt 0) {
  Write-Host ("  Registered method types: {0}" -f ($methodTypes -join ", "))
} else {
  Write-Host "  Registered method types: (none)"
}
Write-Host "  Note: Whether MFA is REQUIRED is determined by Conditional Access, not per-user flags."
