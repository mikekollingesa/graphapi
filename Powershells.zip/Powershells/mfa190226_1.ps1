# ================================
# Config
# ================================
$tenantId     = "9a5cacd0-2bef-4dd7-ac5c-7ebe1f54f495"
$clientId     = "28d48667-10ad-4563-93c3-499438dafbab"
$clientSecret = "iUb8Q~v6_N_C41FVhk7kIarErqlH7ulV4FVWCbVq"

$groupId = "0ef5dc15-0d02-4f8c-8ca6-72bcff871524"


# ================================
# Token (app-only)
# ================================
$tok = Invoke-RestMethod -Method POST -Uri "https://login.microsoftonline.com/$tenantId/oauth2/v2.0/token" -Body @{
  grant_type    = "client_credentials"
  scope         = "https://graph.microsoft.com/.default"
  client_id     = $clientId
  client_secret = $clientSecret
}
$headers = @{ Authorization = "Bearer $($tok.access_token)" }

# ================================
# First 50 users from group
# ================================
$usersUrl = "https://graph.microsoft.com/beta/groups/$groupId/members/microsoft.graph.user?`$top=50&`$select=id,displayName,userPrincipalName"
$users = (Invoke-RestMethod -Headers $headers -Uri $usersUrl).value

# ================================
# For each user: get registration details row (MFA registration fields)
# ================================
$results = foreach ($u in $users) {

  $repUrl = "https://graph.microsoft.com/beta/reports/authenticationMethods/userRegistrationDetails?`$filter=id eq '$($u.id)'"
  try {
    $rep = Invoke-RestMethod -Headers $headers -Uri $repUrl
    $row = if ($rep.value -and $rep.value.Count -gt 0) { $rep.value[0] } else { $null }
  } catch {
    $row = $null
  }

  [PSCustomObject]@{
    DisplayName           = $u.displayName
    UserPrincipalName     = $u.userPrincipalName
    UserId                = $u.id
    IsMfaRegistered       = if ($row) { $row.isMfaRegistered } else { $null }
    MfaRegistrationStatus = if ($row) { $row.mfaRegistrationStatus } else { "NoReportRow/Blocked" }
    DefaultMfaMethod      = if ($row) { $row.defaultMfaMethod } else { "" }
    MethodsRegistered     = if ($row -and $row.methodsRegistered) { ($row.methodsRegistered -join ";") } else { "" }
  }
}

$results | Format-Table -AutoSize

# Optional CSV:
# $results | Export-Csv (Join-Path $PSScriptRoot "MFA_RegDetails_First50.csv") -NoTypeInformation -Encoding UTF8