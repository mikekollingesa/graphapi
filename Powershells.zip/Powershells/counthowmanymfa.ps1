# ==========================================================
# MFA Registration Report - COUNT ONLY (No Group, No Top X)
# ==========================================================

# ================================
# Configuration
# ================================
$tenantId     = "9a5cacd0-2bef-4dd7-ac5c-7ebe1f54f495"
$clientId     = "28d48667-10ad-4563-93c3-499438dafbab"
$clientSecret = "iUb8Q~v6_N_C41FVhk7kIarErqlH7ulV4FVWCbVq"

# ================================
# Token (Graph app-only)
# ================================
$graphTok = Invoke-RestMethod -Method POST `
    -Uri "https://login.microsoftonline.com/$tenantId/oauth2/v2.0/token" `
    -Body @{
        client_id     = $clientId
        client_secret = $clientSecret
        grant_type    = "client_credentials"
        scope         = "https://graph.microsoft.com/.default"
    }

$graphHeaders = @{
    Authorization = "Bearer $($graphTok.access_token)"
    Accept        = "application/json"
}

# ================================
# Helper: Get all pages from Graph
# ================================
function Get-AllPagesJson {
    param([string]$url)

    $all = @()

    do {
        $resp = Invoke-RestMethod -Headers $graphHeaders -Uri $url -Method GET
        if ($resp.value) { $all += $resp.value }
        $url = $resp.'@odata.nextLink'
    } while ($url)

    return $all
}

# ================================
# COUNT ALL MFA REGISTRATION ROWS
# ================================
$reportUrl = "https://graph.microsoft.com/beta/reports/authenticationMethods/userRegistrationDetails?`$top=999"
$reportRows = Get-AllPagesJson $reportUrl

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Total MFA registration report rows: $($reportRows.Count)" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Cyan

# Optional: sanity check unique users
$uniqueUsers = ($reportRows | Select-Object -ExpandProperty id -Unique).Count
Write-Host "Unique user IDs in report: $uniqueUsers" -ForegroundColor Green