# ===========================
# CONFIGURATION
# ===========================
$tenantId     = "9a5cacd0-2bef-4dd7-ac5c-7ebe1f54f495"
$clientId     = "28d48667-10ad-4563-93c3-499438dafbab"
$clientSecret = "iUb8Q~v6_N_C41FVhk7kIarErqlH7ulV4FVWCbVq"

# CSV output file
$csvPath      = "C:\Users\mike.kolling\Downloads\APL_GROUP_SELECTED_USERS_WITH_MFA.csv"

# CSV containing input email addresses (must have a header called 'Email')
$inputCsv     = "C:\Users\mike.kolling\Downloads\TargetEmails.csv"

Write-Host "[$(Get-Date -Format 'HH:mm:ss')] ===== Script starting ====="

# ===========================
# LOAD TARGET EMAILS FROM CSV
# ===========================
if (!(Test-Path $inputCsv)) {
    Write-Error "[$(Get-Date -Format 'HH:mm:ss')] CSV file not found: $inputCsv"
    exit 1
}

Write-Host "[$(Get-Date -Format 'HH:mm:ss')] Reading target emails from $inputCsv ..."
$csvRows = Import-Csv -Path $inputCsv
$targetEmails = @()

foreach ($row in $csvRows) {
    if ($row.Email -and $row.Email.Trim() -ne "") {
        $email = $row.Email.Trim().ToLower()
        $targetEmails += $email
        Write-Host "[$(Get-Date -Format 'HH:mm:ss')] CSV Email loaded: $email"
    } else {
        Write-Warning "[$(Get-Date -Format 'HH:mm:ss')] Skipping row with missing or blank 'Email'"
    }
}

Write-Host "[$(Get-Date -Format 'HH:mm:ss')] Total emails loaded from CSV: $($targetEmails.Count)"
if ($targetEmails.Count -eq 0) {
    Write-Error "[$(Get-Date -Format 'HH:mm:ss')] No valid emails found in CSV. Exiting."
    exit 1
}
Write-Host ""

# ===========================
# GET TOKEN
# ===========================
Write-Host "[$(Get-Date -Format 'HH:mm:ss')] Requesting OAuth token..."
$tokenResponse = Invoke-RestMethod -Method POST -Uri "https://login.microsoftonline.com/$tenantId/oauth2/v2.0/token" -Body @{
    client_id     = $clientId
    scope         = "https://graph.microsoft.com/.default"
    client_secret = $clientSecret
    grant_type    = "client_credentials"
}

$token = $tokenResponse.access_token
if (-not $token) {
    Write-Error "[$(Get-Date -Format 'HH:mm:ss')] Token acquisition failed. Exiting."
    exit 1
}
Write-Host "[$(Get-Date -Format 'HH:mm:ss')] Token acquired successfully."
Write-Host ""

# ===========================
# ENUMERATE ALL USERS (Entra)
# ===========================
Write-Host "[$(Get-Date -Format 'HH:mm:ss')] Fetching all users from Entra (Microsoft Graph)..."
$allUsers = @()
# $baseUrl = "https://graph.microsoft.com/beta/users?`$select=id,displayName,mail,userPrincipalName,externalUserState,externalUserStateChangeDateTime"
$baseUrl = "https://graph.microsoft.com/beta/users?`$select=id,displayName,mail,userPrincipalName,userType,externalUserState,externalUserStateChangeDateTime"


$page = 1
do {
    Write-Host "[$(Get-Date -Format 'HH:mm:ss')] Fetching page $page..."
    try {
        $response = Invoke-RestMethod -Uri $baseUrl -Headers @{
            Authorization = "Bearer $token"
            "Content-Type" = "application/json"
        }
        Write-Host "[$(Get-Date -Format 'HH:mm:ss')] Page $page returned $($response.value.Count) users."
    } catch {
        Write-Error "[$(Get-Date -Format 'HH:mm:ss')] Error fetching users: $($_.Exception.Message)"
        break
    }

    $allUsers += $response.value
    $baseUrl = $response.'@odata.nextLink'
    $page++
} while ($baseUrl)

$total = $allUsers.Count
Write-Host "[$(Get-Date -Format 'HH:mm:ss')] Total users fetched from Entra: $total"
Write-Host ""

# ===========================
# FILTER USERS AGAINST CSV EMAILS
# ===========================
Write-Host "[$(Get-Date -Format 'HH:mm:ss')] Filtering against target emails..."
$filteredUsers = $allUsers | Where-Object {
    $email = if ($_.mail) { $_.mail.ToLower() } else { "" }
    $upn   = if ($_.userPrincipalName) { $_.userPrincipalName.ToLower() } else { "" }
    $targetEmails -contains $email -or $targetEmails -contains $upn
}

if ($filteredUsers.Count -eq 0) {
    Write-Warning "[$(Get-Date -Format 'HH:mm:ss')] No matching users found. Exiting."
    exit 0
}
Write-Host "[$(Get-Date -Format 'HH:mm:ss')] Matched $($filteredUsers.Count) users to target email list."
Write-Host ""

# ===========================
# PROCESS EACH USER
# ===========================
$results = @()
$count = 1
$totalFiltered = $filteredUsers.Count

foreach ($user in $filteredUsers) {
    Write-Host "[$(Get-Date -Format 'HH:mm:ss')] Processing [$count/$totalFiltered]: $($user.displayName) <$($user.userPrincipalName)>"

    $mfaStatus = "Unknown"
    $mfaDetails = ""
    $mfaError = ""

    try {
        $signInsUrl = "https://graph.microsoft.com/v1.0/auditLogs/signIns?`$filter=userId eq '$($user.id)'&`$orderby=createdDateTime desc&`$top=1"
        $signIns = Invoke-RestMethod -Uri $signInsUrl -Headers @{
            Authorization = "Bearer $token"
            "Content-Type" = "application/json"
        }

        if ($signIns.value.Count -gt 0) {
            $signIn = $signIns.value[0]
            $details = $signIn.status.additionalDetails

            if ($details -match "MFA requirement satisfied|MFA completed") {
                $mfaStatus = "Yes"
            } elseif ($details -match "needs to perform multi-factor") {
                $mfaStatus = "RequiredButNotCompleted"
            } else {
                $mfaStatus = "No"
            }

            $mfaDetails = $details
        } else {
            $mfaStatus = "NoSignIns"
        }
    } catch {
        $mfaStatus = "Error"
        $mfaError = "$($_.Exception.Message) | URL: $signInsUrl"
    }

    Write-Host "[$(Get-Date -Format 'HH:mm:ss')] MFA Status for $($user.userPrincipalName): $mfaStatus"

$results += [PSCustomObject]@{
    DisplayName                     = $user.displayName
    Mail                            = $user.mail
    UPN                             = $user.userPrincipalName
    OID                             = $user.id
    UserType                        = $user.userType          # ✅ NEW LINE
    MFAEnabled                      = $mfaStatus
    MFAError                        = $mfaError
    MFADetails                      = $mfaDetails
    ExternalUserState               = $user.externalUserState
    ExternalUserStateChangeDateTime = $user.externalUserStateChangeDateTime
}


    $count++
}

# ===========================
# EXPORT TO CSV
# ===========================
try {
    Write-Host "[$(Get-Date -Format 'HH:mm:ss')] Exporting results to $csvPath ..."
    $results | Export-Csv -Path $csvPath -NoTypeInformation
    Write-Host "[$(Get-Date -Format 'HH:mm:ss')] CSV exported successfully."
} catch {
    Write-Error "[$(Get-Date -Format 'HH:mm:ss')] CSV export failed: $($_.Exception.Message)"
}

Write-Host "[$(Get-Date -Format 'HH:mm:ss')] ===== Script finished ====="
