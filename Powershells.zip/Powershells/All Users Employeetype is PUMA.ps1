# Azure AD App Credentials
$tenantId     = "9a5cacd0-2bef-4dd7-ac5c-7ebe1f54f495"
$clientId     = "28d48667-10ad-4563-93c3-499438dafbab"
$clientSecret = "iUb8Q~v6_N_C41FVhk7kIarErqlH7ulV4FVWCbVq"

# Get access token
$tokenResponse = Invoke-RestMethod -Method POST -Uri "https://login.microsoftonline.com/$tenantId/oauth2/v2.0/token" -Body @{
    client_id     = $clientId
    scope         = "https://graph.microsoft.com/.default"
    client_secret = $clientSecret
    grant_type    = "client_credentials"
}
$token = $tokenResponse.access_token

# Base URL with no filter
$baseUrl = "https://graph.microsoft.com/beta/users?%24top=999"
$allUsers = @()

while ($baseUrl) {
    try {
        $response = Invoke-RestMethod -Uri $baseUrl -Headers @{
            Authorization = "Bearer $token"
            "Content-Type" = "application/json"
        }

        $allUsers += $response.value
        $baseUrl = $response.'@odata.nextLink'
        Write-Host "Retrieved $($allUsers.Count) users so far..."
    }
    catch {
        Write-Warning "Request failed at $baseUrl"
        break
    }
}

# Now filter locally in PowerShell
$pumaUsers = $allUsers | Where-Object { $_.employeeType -eq 'PUMA' }

# Export filtered results
$pumaUsers |
    Select-Object displayName, mail, userPrincipalName, id, employeeType |
    Export-Csv -Path "C:\Users\mike.kolling\Downloads\puma_users.csv" -NoTypeInformation

Write-Host "✅ Exported $($pumaUsers.Count) users with employeeType = 'PUMA'"
