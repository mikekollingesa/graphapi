# Static bearer token – replace this with a secure token method in production
# Azure AD App Credentials
$tenantId     = "9a5cacd0-2bef-4dd7-ac5c-7ebe1f54f495"
$clientId     = "28d48667-10ad-4563-93c3-499438dafbab"
$clientSecret = "iUb8Q~v6_N_C41FVhk7kIarErqlH7ulV4FVWCbVq"

# Get access token
$tokenResponse = Invoke-RestMethod -Method POST -Uri "https://login.microsoftonline.com/$tenantId/oauth2/v2.0/token" -Body @{
    client_id     = $clientId
    scope         = "https://graph.microsoft.com/.default"
    client_secret = $clientSecret
    grant_type    = "client_credentials"
}

$token = $tokenResponse.access_token
# Group ID you want to query
 $groupId = "e3fe1293-d3cf-4ffe-9afa-2b63749412c6"   # GROUP:  APL_DSP_PRD
#$groupId = "0ef5dc15-0d02-4f8c-8ca6-72bcff871524"   # GROUP APL_BLUEDOCS_PRD




# Initial API request URL
$baseUrl = "https://graph.microsoft.com/beta/groups/$groupId/members/microsoft.graph.user?`$select=displayName,mail"

# Collect all user results here
$allUsers = @()

do {
    $response = Invoke-RestMethod -Uri $baseUrl -Headers @{
        Authorization = "Bearer $token"
        "Content-Type" = "application/json"
    }

    # Append current page results
    $allUsers += $response.value

    # Check for pagination
    $baseUrl = $response.'@odata.nextLink'

} while ($baseUrl)

# Export the selected fields to CSV


$allUsers |
  Select-Object displayName, mail |
  Export-Csv -Path "C:\Users\mike.kolling\Downloads\APL_DSP_PRD_group_members.csv" -NoTypeInformation

  

Write-Host "✅ Group members exported to group_members.csv"
