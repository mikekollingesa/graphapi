# ================================
# OPTION B (Delegated auth)
# MFA registration/methods for users in ONE Entra group
# ================================

# ---- Config ----
$groupId = "0ef5dc15-0d02-4f8c-8ca6-72bcff871524"
$csvPath = "C:\Users\mike.kolling\Downloads\MFA_Methods_Group_0ef5dc15.csv"

# ---- Connect using delegated scopes (interactive) ----
# This matches the internal guidance: Connect-MgGraph -Scopes "UserAuthenticationMethod.Read.All,User.Read.All" [1](https://teams.microsoft.com/l/message/19:7f073a729a924e0581ccd7aadf159af9@thread.v2/1750787119652?context=%7B%22contextType%22:%22chat%22%7D)
Import-Module Microsoft.Graph -ErrorAction Stop

$scopes = @(
    "User.Read.All",
    "GroupMember.Read.All",
    "UserAuthenticationMethod.Read.All"
)

Connect-MgGraph -Scopes $scopes | Out-Null

# Optional: show who you're connected as
$ctx = Get-MgContext
Write-Host "Connected. TenantId=$($ctx.TenantId) Account=$($ctx.Account)" -ForegroundColor Green

# ---- Helper: map @odata.type to friendly method name ----
function Get-MethodLabel($odataType) {
    switch ($odataType) {
        "#microsoft.graph.microsoftAuthenticatorAuthenticationMethod" { "MicrosoftAuthenticator" }
        "#microsoft.graph.passwordlessMicrosoftAuthenticatorAuthenticationMethod" { "PasswordlessAuthenticator" }
        "#microsoft.graph.phoneAuthenticationMethod" { "Phone" }
        "#microsoft.graph.fido2AuthenticationMethod" { "FIDO2" }
        "#microsoft.graph.windowsHelloForBusinessAuthenticationMethod" { "WindowsHelloForBusiness" }
        "#microsoft.graph.softwareOathAuthenticationMethod" { "SoftwareOATH" }
        "#microsoft.graph.temporaryAccessPassAuthenticationMethod" { "TemporaryAccessPass" }
        "#microsoft.graph.emailAuthenticationMethod" { "Email" }
        default { $odataType }
    }
}

# ---- Helper: choose a "default" method (Graph doesn't always expose user's chosen default) ----
function Infer-DefaultMfaMethod([string[]]$methodLabels) {
    if ($methodLabels -contains "MicrosoftAuthenticator") { return "MicrosoftAuthenticator" }
    if ($methodLabels -contains "PasswordlessAuthenticator") { return "PasswordlessAuthenticator" }
    if ($methodLabels -contains "FIDO2") { return "FIDO2" }
    if ($methodLabels -contains "WindowsHelloForBusiness") { return "WindowsHelloForBusiness" }
    if ($methodLabels -contains "Phone") { return "Phone" }
    if ($methodLabels -contains "SoftwareOATH") { return "SoftwareOATH" }
    if ($methodLabels -contains "TemporaryAccessPass") { return "TemporaryAccessPass" }
    return ""
}

# ---- Get group members (users only) ----
Write-Host "Fetching members of group $groupId ..." -ForegroundColor Cyan

# Get all members then filter to users (Graph PS returns directoryObject types)
$members = Get-MgGroupMember -GroupId $groupId -All

# Filter only user objects and get basic identity fields
$userMembers = @()
foreach ($m in $members) {
    if ($m.AdditionalProperties.'@odata.type' -eq "#microsoft.graph.user") {
        # Fetch full user for UPN/mail reliably
        $u = Get-MgUser -UserId $m.Id -Property "id,displayName,userPrincipalName,mail" -ErrorAction SilentlyContinue
        if ($u) { $userMembers += $u }
    }
}

Write-Host "Users found: $($userMembers.Count)" -ForegroundColor Green

# ---- Iterate users and pull authentication methods ----
$results = New-Object System.Collections.Generic.List[object]
$count = 1

# MFA-capable methods for "registered" determination
$mfaCapable = @(
    "MicrosoftAuthenticator",
    "PasswordlessAuthenticator",
    "Phone",
    "FIDO2",
    "WindowsHelloForBusiness",
    "SoftwareOATH",
    "TemporaryAccessPass"
)

foreach ($u in $userMembers) {
    Write-Host "[$count/$($userMembers.Count)] $($u.UserPrincipalName)" -ForegroundColor Gray

    $methodLabels = @()
    $isMfaRegistered = $null
    $registrationStatus = "Unknown"
    $defaultMethod = ""

    try {
        # Equivalent of the internal example using Get-MgUserAuthenticationMethod [1](https://teams.microsoft.com/l/message/19:7f073a729a924e0581ccd7aadf159af9@thread.v2/1750787119652?context=%7B%22contextType%22:%22chat%22%7D)
        $methods = Get-MgUserAuthenticationMethod -UserId $u.Id -ErrorAction Stop

        foreach ($method in $methods) {
            $odata = $method.AdditionalProperties.'@odata.type'
            if ($odata) {
                $methodLabels += (Get-MethodLabel $odata)
            }
        }

        $methodLabels = $methodLabels | Sort-Object -Unique
        $hasMfaCapable = ($methodLabels | Where-Object { $_ -in $mfaCapable }).Count -gt 0

        $isMfaRegistered = $hasMfaCapable
        $registrationStatus = if ($hasMfaCapable) { "Registered" } else { "NotRegistered" }
        $defaultMethod = Infer-DefaultMfaMethod -methodLabels $methodLabels
    }
    catch {
        # If delegated scopes still aren't sufficient, capture the error cleanly
        $registrationStatus = "Error: $($_.Exception.Message)"
        $isMfaRegistered = $null
        $methodLabels = @()
        $defaultMethod = ""
    }

    $results.Add([PSCustomObject]@{
        Username              = $u.UserPrincipalName
        UserId                = $u.Id
        IsMfaRegistered       = $isMfaRegistered
        MfaRegistrationStatus = $registrationStatus
        DefaultMfaMethod      = $defaultMethod
        MethodsRegistered     = ($methodLabels -join ";")
    })

    $count++
}

# ---- Export ----
$results | Export-Csv -Path $csvPath -NoTypeInformation -Encoding UTF8
Write-Host "`nExported to: $csvPath" -ForegroundColor Green

# ---- Disconnect ----
Disconnect-MgGraph | Out-Null