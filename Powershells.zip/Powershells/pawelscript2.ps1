#Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope Process

$inputCsv="INPUT.csv"
$outputCsv="OUTPUT.csv"

$tenantId     = "9a5cacd0-2bef-4dd7-ac5c-7ebe1f54f495"
$clientId     = "28d48667-10ad-4563-93c3-499438dafbab"
$clientSecret = Read-Host "Enter Client Secret" 

$password = ConvertTo-SecureString $clientSecret -AsPlainText -Force
$Cred = New-Object System.Management.Automation.PSCredential ($clientId , $password)
Connect-MgGraph -ClientSecretCredential $Cred -TenantId $tenantId -NoWelcome

$batchSize=20
$userDetails=@()
$emailsCounter=0
$batchCounter=0
$batch=@()
$Bluedocs=0
$Esap=0
$Badge=0
$DST=0
$DAM=0
$Accepted=0
$Pending=0
$Guests=0
$Delegates = @{}

$CSVFile = Import-Csv $inputCsv

ForEach($Line in $CSVFile)
{
    $userEmail=$Line."E-mail"
    $Delegates[$userEmail]= [PSCustomObject]@{
     Bluedocs = $Line."blue-docs Access Request"
     Esap     = $Line."esa-p Access Request"
     Badge    = $Line."Badge request"
     DST      = $Line."DST Access Request"
     DAM      = $Line."User has a DAM account"
    }
    $batch += $userEmail
    $emailsCounter += 1
    $batchCounter += 1
    if (($batchCounter -ge $batchSize) -or ($emailsCounter -ge $CSVFile.Count )) {
        $requests = @()
        $requestCounter=1
        foreach ($email in $batch) {
            $requests += @{
                id     = "$requestCounter"
                method = "GET"
                url    = "users?`$filter=mail eq '$email'&`$select=userPrincipalName,givenName,surname,displayName,mail,id,externalUserState,externalUserStateChangeDateTime"
            }
            $requestCounter += 1
        }
        $batchCounter=0
        $batch=@()
        $batchBody = @{ requests = $requests } | ConvertTo-Json -Depth 5
        $response = Invoke-MgGraphRequest -Method POST -Uri "https://graph.microsoft.com/beta/`$batch" -Body $batchBody -ContentType "application/json"

        foreach ($res in $response.responses) {
            if ($res.status -eq 200 -and $res.body.value.Count -gt 0) {
                $user = $res.body.value[0]
                $ExtStateChangedOn = $null
                try {$ExtStateChangedOn=[DateTime]::Parse($user.externalUserStateChangeDateTime)} catch {}
                $PumaInfo=$Delegates[$user.mail] 
                $userDetail = [PSCustomObject]@{
                    UPN              = $user.userPrincipalName
                    DisplayName      = $user.displayName
                    Mail             = $user.mail
                    Id               = $user.id
                    ExtState         = $user.externalUserState
                    ExtStateChangedOn= $ExtStateChangedOn
                    Bluedocs = $PumaInfo.Bluedocs
                    Esap     = $PumaInfo.Esap
                    Badge    = $PumaInfo.Badge
                    DST      = $PumaInfo.DST
                    DAM      = $PumaInfo.DAM
                }
                $userDetails += $userDetail
                $Guests += 1
                if ($PumaInfo.Bluedocs -eq "Yes") { $Bluedocs += 1 }
                if ($PumaInfo.Esap -eq "Yes") { $Esap += 1 }
                if ($PumaInfo.Badge -eq "Yes") { $Badge += 1 }
                if ($PumaInfo.DST -eq "Yes") { $DST += 1 }
                if ($PumaInfo.DAM -eq "Yes") { $DAM += 1 }
                if ($userDetail.ExtState -eq "Accepted") { $Accepted += 1 }
                if ($userDetail.ExtState -eq "PendingAcceptance") { $Pending += 1 }
            }
        }
    }
}

"{0,-10}: {1,5}" -f "Delegates",$CSVFile.Count
"{0,-10}: {1,5}" -f "Guests",$Guests
"{0,-10}: {1,5}" -f "Accepted",$Accepted
"{0,-10}: {1,5}" -f "Pending",$Pending
"{0,-10}: {1,5}" -f "Bluedocs",$Bluedocs
"{0,-10}: {1,5}" -f "DST",$DST
"{0,-10}: {1,5}" -f "ESA-P",$Esap
"{0,-10}: {1,5}" -f "Badge",$Badge
"{0,-10}: {1,5}" -f "DAM",$DAM

$userDetails | Export-Csv  -NoTypeInformation -Path $outputCsv