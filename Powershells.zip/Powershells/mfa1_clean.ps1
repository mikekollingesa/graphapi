# --- Configuration ---
$tenantId     = "9a5cacd0-2bef-4dd7-ac5c-7ebe1f54f495"
$clientId     = "28d48667-10ad-4563-93c3-499438dafbab"
$clientSecret = "iUb8Q~v6_N_C41FVhk7kIarErqlH7ulV4FVWCbVq"
#$groupId      = "0ef5dc15-0d02-4f8c-8ca6-72bcff871524"

$groupId      = "11a97d98-c0ed-4309-a5f1-8e0add9f546f"
$csvPath      = "C:\Users\mike.kolling\Downloads\APL_GROUP_USERS_WITH_MFA.csv"

# --- Get token ---
Write-Host "`nGetting token..."
$tokenResponse = Invoke-RestMethod -Method POST -Uri "https://login.microsoftonline.com/$tenantId/oauth2/v2.0/token" -Body @{
    client_id     = $clientId
    scope         = "https://graph.microsoft.com/.default"
    client_secret = $clientSecret
    grant_type    = "client_credentials"
}
$token = $tokenResponse.access_token

if (-not $token) {
    Write-Error "Token failed."
    exit 1
}
Write-Host "Token OK.`n"

# --- Get users in group ---
$allUsers = @()
$baseUrl = "https://graph.microsoft.com/beta/groups/$groupId/members/microsoft.graph.user?`$select=id,displayName,mail,userPrincipalName,externalUserState,externalUserStateChangeDateTime"

$page = 1
do {
    Write-Host "Fetching page $page..."
    try {
        $response = Invoke-RestMethod -Uri $baseUrl -Headers @{
            Authorization = "Bearer $token"
            "Content-Type" = "application/json"
        }
    } catch {
        Write-Error "Failed to get group members: $($_.Exception.Message)"
        break
    }

    $allUsers += $response.value
    $baseUrl = $response.'@odata.nextLink'
    $page++
} while ($baseUrl)

$total = $allUsers.Count
Write-Host "`nTotal users: $total`n"

# --- Process each user for MFA sign-in info ---
$results = @()
$count = 1

foreach ($user in $allUsers) {
    Write-Host "[$count/$total] $($user.displayName) <$($user.userPrincipalName)>"

    $mfaStatus = "Unknown"
    $mfaDetails = ""
    $mfaError = ""

    try {
        $signInsUrl = "https://graph.microsoft.com/v1.0/auditLogs/signIns?`$filter=userId eq '$($user.id)'&`$orderby=createdDateTime desc&`$top=1"
        $signIns = Invoke-RestMethod -Uri $signInsUrl -Headers @{
            Authorization = "Bearer $token"
            "Content-Type" = "application/json"
        }

        if ($signIns.value.Count -gt 0) {
            $signIn = $signIns.value[0]
            $details = $signIn.status.additionalDetails

            if ($details -match "MFA requirement satisfied|MFA completed") {
                $mfaStatus = "Yes"
            } elseif ($details -match "needs to perform multi-factor") {
                $mfaStatus = "RequiredButNotCompleted"
            } else {
                $mfaStatus = "No"
            }

            $mfaDetails = $details
        } else {
            $mfaStatus = "NoSignIns"
        }
    } catch {
        $mfaStatus = "Error"
        $mfaError = "$($_.Exception.Message) | URL: $signInsUrl"
    }

    $results += [PSCustomObject]@{
        DisplayName                     = $user.displayName
        Mail                            = $user.mail
        UPN                             = $user.userPrincipalName
        OID                             = $user.id
        MFAEnabled                      = $mfaStatus
        MFAError                        = $mfaError
        MFADetails                      = $mfaDetails
        ExternalUserState              = $user.externalUserState
        ExternalUserStateChangeDateTime = $user.externalUserStateChangeDateTime
    }

    $count++
}

# --- Export to CSV ---
try {
    $results | Export-Csv -Path $csvPath -NoTypeInformation
    Write-Host "`nCSV exported to: $csvPath"
} catch {
    Write-Error "CSV export failed: $($_.Exception.Message)"
}
