# ==========================================================
# MFA Registration -> Dataverse (Upsert) for first 50 group users
# ==========================================================

# ================================
# Configuration
# ================================
$tenantId     = "9a5cacd0-2bef-4dd7-ac5c-7ebe1f54f495"
$clientId     = "28d48667-10ad-4563-93c3-499438dafbab"
$clientSecret = "iUb8Q~v6_N_C41FVhk7kIarErqlH7ulV4FVWCbVq"   # <-- replace with your secret

# Single Group ID (only)
$groupId = "0ef5dc15-0d02-4f8c-8ca6-72bcff871524"

# Dataverse environment URL (MUST include https:// and no trailing slash)
$dataverseUrl = "https://orgca79d528.crm4.dynamics.com"

# Dataverse table entity set name (plural)
$tableSetName = "new_mfadatas"

# Alternate key logical name (you created key "userid" on column UserId -> logical new_userid)
$alternateKey = "new_userid"

# ================================
# Token (Graph app-only)
# ================================
$graphTok = Invoke-RestMethod -Method POST -Uri "https://login.microsoftonline.com/$tenantId/oauth2/v2.0/token" -Body @{
  client_id     = $clientId
  client_secret = $clientSecret
  grant_type    = "client_credentials"
  scope         = "https://graph.microsoft.com/.default"
}

$graphHeaders = @{
  Authorization = "Bearer $($graphTok.access_token)"
  Accept        = "application/json"
}

# ================================
# Token (Dataverse app-only)  *** FIXED SCOPE ***
# ================================
# Make sure the URL is exactly "https://<org>.crmX.dynamics.com" (no trailing slash)
$dataverseUrl = $dataverseUrl.TrimEnd('/')
if ($dataverseUrl -notmatch '^https://') { $dataverseUrl = "https://$dataverseUrl" }

$dvTok = Invoke-RestMethod -Method POST -Uri "https://login.microsoftonline.com/$tenantId/oauth2/v2.0/token" -Body @{
  client_id     = $clientId
  client_secret = $clientSecret
  grant_type    = "client_credentials"
  scope         = "$dataverseUrl/.default"
}

$dvHeaders = @{
  Authorization      = "Bearer $($dvTok.access_token)"
  Accept             = "application/json"
  "Content-Type"     = "application/json; charset=utf-8"
  "OData-Version"    = "4.0"
  "OData-MaxVersion" = "4.0"
}

# ================================
# Helper: Get all pages from a Graph endpoint returning JSON + @odata.nextLink
# ================================
function Get-AllPagesJson([string]$url) {
  $all = @()
  do {
    $resp = Invoke-RestMethod -Headers $graphHeaders -Uri $url -Method GET
    if ($resp.value) { $all += $resp.value }
    $url = $resp.'@odata.nextLink'
  } while ($url)
  return $all
}

# ================================
# Helper: Dataverse Upsert by Alternate Key (PATCH)
# ================================
function Upsert-DataverseRow {
  param(
    [Parameter(Mandatory=$true)][string]$KeyValue,
    [Parameter(Mandatory=$true)][psobject]$BodyObject
  )

  # Escape single quotes for OData key syntax
  $escapedKey = $KeyValue.Replace("'","''")

  # Upsert endpoint using alternate key
  $uri = "$dataverseUrl/api/data/v9.2/$tableSetName($alternateKey='$escapedKey')"
  $json = ($BodyObject | ConvertTo-Json -Depth 10)

  Invoke-RestMethod -Method PATCH -Uri $uri -Headers $dvHeaders -Body $json -ErrorAction Stop
}

# ================================
# 1) First 50 users from group
# ================================
$usersUrl = "https://graph.microsoft.com/beta/groups/$groupId/members/microsoft.graph.user?`$top=50&`$select=id,displayName,userPrincipalName"
$users = (Invoke-RestMethod -Headers $graphHeaders -Uri $usersUrl -Method GET).value
Write-Host "Users pulled from group: $($users.Count)" -ForegroundColor Green

# ================================
# 2) Full MFA registration report (paged)
# ================================
$reportUrl = "https://graph.microsoft.com/beta/reports/authenticationMethods/userRegistrationDetails?`$top=999"
$reportRows = Get-AllPagesJson $reportUrl
Write-Host "Report rows pulled: $($reportRows.Count)" -ForegroundColor Green

# Index report by user id for fast join
$reportById = @{}
foreach ($r in $reportRows) { $reportById[$r.id] = $r }

# ================================
# 3) Join + output + Upsert into Dataverse
# ================================
$results = foreach ($u in $users) {
  $r = $reportById[$u.id]

  [PSCustomObject]@{
    DisplayName           = $u.displayName
    Email                 = $u.userPrincipalName
    UserId                = $u.id
    IsMfaRegistered       = if ($r) { $r.isMfaRegistered } else { $null }
    MfaRegistrationStatus = if ($r) { $r.mfaRegistrationStatus } else { "NoReportRow" }
    DefaultMethod         = if ($r) { $r.defaultMfaMethod } else { "" }
    MethodsRegistered     = if ($r -and $r.methodsRegistered) { ($r.methodsRegistered -join ";") } else { "" }
  }
}

$results | Format-Table -AutoSize

Write-Host "Upserting $($results.Count) rows into Dataverse..." -ForegroundColor Cyan

$ok = 0
$fail = 0

foreach ($row in $results) {
  # Map to YOUR Dataverse columns (logical names from your screenshot)
  $dvBody = [pscustomobject]@{
    new_displayname            = $row.DisplayName
    new_email                  = $row.Email
    new_userid                 = $row.UserId
    new_ismfaregistered        = $row.IsMfaRegistered
    new_mfaregistrationstatus  = $row.MfaRegistrationStatus
    new_defaultmethod          = $row.DefaultMethod
    new_methodsregistered      = $row.MethodsRegistered
  }

  try {
    Upsert-DataverseRow -KeyValue $row.UserId -BodyObject $dvBody
    $ok++
  }
  catch {
    $fail++
    Write-Warning "FAILED upsert for $($row.Email) / $($row.UserId): $($_.Exception.Message)"
  }
}

Write-Host "DONE. Success=$ok Failed=$fail" -ForegroundColor Green

# Optional export
# $results | Export-Csv -Path (Join-Path $PSScriptRoot "MFA_RegDetails_GroupFirst50.csv") -NoTypeInformation -Encoding UTF8