# Variables
$CSVFilePath = "C:\Users\mike.kolling\Downloads\msr.csv"
$OutputFilePath = "C:\Users\mike.kolling\Downloads\delegates_2025-06-09.csv"

# Azure AD App Registration Info
$tenantId = "9a5cacd0-2bef-4dd7-ac5c-7ebe1f54f495"
$clientId = "28d48667-10ad-4563-93c3-499438dafbab"
$clientSecret = "iUb8Q~v6_N_C41FVhk7klarErqlH7ulV4FVWCbVq"

# Load URL Encoding
Add-Type -AssemblyName System.Web

# Function: Get OAuth Token
function Get-GraphToken {
    $body = @{
        grant_type    = "client_credentials"
        client_id     = $clientId
        client_secret = $clientSecret
        scope         = "https://graph.microsoft.com/.default"
    }

    $response = Invoke-RestMethod -Method Post `
        -Uri "https://login.microsoftonline.com/$tenantId/oauth2/v2.0/token" `
        -Body $body `
        -ContentType "application/x-www-form-urlencoded"

    return $response.access_token
}

# Get access token
$accessToken = Get-GraphToken

# Prepare headers
$headers = @{
    "Authorization"    = "Bearer $accessToken"
    "ConsistencyLevel" = "eventual"
    "Content-Type"     = "application/json"
}

# Import CSV
$CSVFile = Import-Csv -Path $CSVFilePath
$users = @()

foreach ($line in $CSVFile) {
    if ($line.PSObject.Properties['E-mail'] -and $line.'E-mail') {
        $email = $line.'E-mail'.Trim()
    } else {
        Write-Warning "Missing or invalid email in row: $($line | Out-String)"
        continue
    }

    if (-not [string]::IsNullOrEmpty($email)) {
        $url = "https://graph.microsoft.com/beta/users?`$top=1&`$filter=mail eq '$email'"

        try {
            $response = Invoke-RestMethod -Uri $url -Headers $headers -Method Get
            if ($response.value) {
                $users += $response.value
            }
        } catch {
            Write-Warning "Failed for email: $email"
            Write-Host $_.Exception.Message
            if ($_.Exception.Response -ne $null) {
                $reader = New-Object System.IO.StreamReader($_.Exception.Response.GetResponseStream())
                $reader.BaseStream.Position = 0
                $reader.DiscardBufferedData()
                $responseBody = $reader.ReadToEnd()
                Write-Host "Response body: $responseBody"
            }
        }
    }
}

# Select desired properties
$selectedUsers = $users | Select-Object mail,creationType,companyName,userPrincipalName,externalUserState,externalUserStateChangeDateTime,externalUserConvertedOn,id

# Export to CSV
$selectedUsers | Export-Csv -NoTypeInformation -Path $OutputFilePath

Write-Host "`n✅ Export complete to: $OutputFilePath"
