# Install required modules
Install-Module -Name Microsoft.Graph -Scope CurrentUser
Import-Module Microsoft.Graph.Users

# Connect using client credentials
$tenantId = "9a5cacd0-2bef-4dd7-ac5c-7ebe1f54f495"
$clientId = "8b61fdf1-98ae-4d4a-aeb8-396455123973"
$clientSecret = "HG58Q~tf345EYB_.~VJlz8lc_ym.WdplX7krgbP4"

$secureSecret = ConvertTo-SecureString $clientSecret -AsPlainText -Force
$graphScopes = @("https://graph.microsoft.com/.default")

Connect-MgGraph -ClientId $clientId -TenantId $tenantId -ClientSecret $secureSecret -Scopes $graphScopes




# Get all users
$users = Get-MgUser -All

# Select properties to export
$usersData = $users | Select-Object DisplayName, UserPrincipalName, Mail, JobTitle, Department

# Export to Excel (Install ImportExcel if needed)
Install-Module -Name ImportExcel -Scope CurrentUser -Force -AllowClobber
$exportPath = "$env:USERPROFILE\Documents\entra_users.xlsx"
$usersData | Export-Excel -Path $exportPath -AutoSize -WorksheetName "Users"
