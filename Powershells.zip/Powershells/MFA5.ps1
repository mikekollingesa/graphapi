# ================================
# Config
# ================================
$tenantId     = "9a5cacd0-2bef-4dd7-ac5c-7ebe1f54f495"
$clientId     = "28d48667-10ad-4563-93c3-499438dafbab"
$clientSecret = "iUb8Q~v6_N_C41FVhk7kIarErqlH7ulV4FVWCbVq"

$GroupIds = @(
  "0ef5dc15-0d02-4f8c-8ca6-72bcff871524",
  "74bc3edd-5332-42a0-bee4-bdd0b28e019f",
  "cabd421f-0cc4-456a-8519-c1b58ce34566",
  "186b132d-0706-4c05-a128-2a9bd1930bda",
  "11a97d98-c0ed-4309-a5f1-8e0add9f546f",
  "fb28765c-b957-474b-8366-2f9dd5786a24",
  "b82daeb0-2c00-4d53-890b-fdd1a92bd3d3"
)

# ================================
# Get Token
# ================================
$body = @{
  Grant_Type    = "client_credentials"
  Scope         = "https://graph.microsoft.com/.default"
  Client_Id     = $clientId
  Client_Secret = $clientSecret
}
Write-Host "[DEBUG] Getting token..."
$tokenReq = Invoke-RestMethod -Method Post -Uri "https://login.microsoftonline.com/$tenantId/oauth2/v2.0/token" -Body $body
$AccessToken = $tokenReq.access_token
Write-Host "[DEBUG] Token OK."

# ================================
# Function: group members (beta)
# ================================
function Get-GroupMembers {
  param($groupId)
  Write-Host "[DEBUG] Group $groupId..."
  $url = "https://graph.microsoft.com/beta/groups/$groupId/members?$top=999"
  $members = @()
  do {
    $resp = Invoke-RestMethod -Headers @{Authorization = "Bearer $AccessToken"} -Uri $url -Method Get
    $members += $resp.value
    $url = $resp.'@odata.nextLink'
  } while ($url)
  return $members | Where-Object { $_.'@odata.type' -eq '#microsoft.graph.user' }
}

# ================================
# Function: MFA methods (beta)
# ================================
function Get-MFAMethods {
  param($userId)
  $url = "https://graph.microsoft.com/beta/users/$userId/authentication/strongAuthenticationMethods"
  try {
    $resp = Invoke-RestMethod -Headers @{Authorization = "Bearer $AccessToken"} -Uri $url -Method Get
    return $resp.value
  }
  catch {
    Write-Warning "[WARN] MFA check failed for $userId : $($_.Exception.Message)"
    return @()
  }
}

# ================================
# Main
# ================================
$results = @()

foreach ($gid in $GroupIds) {
  $members = Get-GroupMembers -groupId $gid
  foreach ($m in $members) {
    $methods = Get-MFAMethods -userId $m.id
    $hasMFA = $methods.Count -gt 0
    $methodNames = ($methods | ForEach-Object { $_.'@odata.type' }) -join ", "
    Write-Host "[DEBUG] User: $($m.displayName) ($($m.userPrincipalName)) | MFA: $hasMFA | Methods: $methodNames"

    $results += [PSCustomObject]@{
      GroupId           = $gid
      DisplayName       = $m.displayName
      UserPrincipalName = $m.userPrincipalName
      MFAState          = if ($hasMFA) { "Enabled" } else { "Not Enabled" }
      MethodsRegistered = $methodNames
      Id                = $m.id
      Mail              = $m.mail
      JobTitle          = $m.jobTitle
      AccountEnabled    = $m.accountEnabled
    }
  }
}

# ================================
# Export
# ================================
$csv = Join-Path $PSScriptRoot "MFAStatus.csv"
$results | Export-Csv -Path $csv -NoTypeInformation -Encoding UTF8
Write-Host "[DEBUG] Exported to $csv"
