# =====================================================================
# Single-user RESOLVE script (no CSV)
# - Resolves guest/member by external email (mail/otherMails/identities)
# - Checks DIRECT and TRANSITIVE membership against provided groups
# - Shows last sign-in from:
#     1) v1.0 auditLogs/signIns (most recent interactive sign-in)
#     2) signInActivity rollup on the user
#
# Required application permissions (grant + admin consent):
#   - Directory.Read.All OR User.Read.All
#   - AuditLog.Read.All (for sign-in logs and signInActivity)
#   - Group.Read.All (for membership checks)
# =====================================================================

# ---------- CONFIG ----------
$tenantId     = "9a5cacd0-2bef-4dd7-ac5c-7ebe1f54f495"
$clientId     = "28d48667-10ad-4563-93c3-499438dafbab"
$clientSecret = "iUb8Q~v6_N_C41FVhk7kIarErqlH7ulV4FVWCbVq"

# Target external email (guest address)
$targetEmail  = 'p.baldauf@aiic.net'

# Group IDs to check
$groupIds = @(
    "0ef5dc15-0d02-4f8c-8ca6-72bcff871524",
    "74bc3edd-5332-42a0-bee4-bdd0b28e019f",
    "cabd421f-0cc4-456a-8519-c1b58ce34566",
    "186b132d-0706-4c05-a128-2a9bd1930bda",
    "11a97d98-c0ed-4309-a5f1-8e0add9f546f",
    "fb28765c-b957-474b-8366-2f9dd5786a24",
    "b82daeb0-2c00-4d53-890b-fdd1a92bd3d3"
)

# ---------- TOKEN ----------
Write-Host "`nGetting access token..."
$tokenResponse = Invoke-RestMethod -Method POST -Uri "https://login.microsoftonline.com/$tenantId/oauth2/v2.0/token" -Body @{
  client_id     = $clientId
  scope         = "https://graph.microsoft.com/.default"
  client_secret = $clientSecret
  grant_type    = "client_credentials"
}
$token = $tokenResponse.access_token
$auth  = @{ Authorization = "Bearer $token" }
Write-Host "Access token acquired.`n"

# ---------- HELPERS ----------
function Invoke-Graph {
  param([Parameter(Mandatory)][string] $Uri)
  Invoke-RestMethod -Method GET -Uri $Uri -Headers $auth -ErrorAction Stop
}

function Get-DefaultTenantDomain {
  $org = Invoke-Graph "https://graph.microsoft.com/v1.0/organization?`$select=verifiedDomains"
  $domains = $org.value[0].verifiedDomains
  $default = ($domains | Where-Object { $_.isDefault -eq $true }).name
  if (-not $default) { $default = ($domains | Where-Object { $_.isInitial -eq $true }).name }
  return $default
}

function Resolve-User {
  param([string] $email)

  # 1) Try direct UPN (works for members; guests usually 404)
  try {
    $u = Invoke-Graph "https://graph.microsoft.com/v1.0/users/$email?`$select=id,displayName,userPrincipalName,mail,otherMails,userType"
    if ($u) { return $u }
  } catch { }

  # 2) mail eq '{email}'
  try {
    $r = Invoke-Graph "https://graph.microsoft.com/v1.0/users?`$select=id,displayName,userPrincipalName,mail,otherMails,userType&`$filter=mail eq '$email'"
    if ($r.value.Count -gt 0) { return $r.value[0] }
  } catch { }

  # 3) otherMails contains '{email}'
  try {
    $r = Invoke-Graph "https://graph.microsoft.com/v1.0/users?`$select=id,displayName,userPrincipalName,mail,otherMails,userType&`$filter=otherMails/any(m:m eq '$email')"
    if ($r.value.Count -gt 0) { return $r.value[0] }
  } catch { }

  # 4) identities (issuerAssignedId == email & issuer == tenant default domain) — beta
  try {
    $issuer = Get-DefaultTenantDomain
    $r = Invoke-Graph "https://graph.microsoft.com/beta/users?`$select=id,displayName,userPrincipalName,mail,otherMails,userType&`$filter=identities/any(c:c/issuerAssignedId eq '$email' and c/issuer eq '$issuer')"
    if ($r.value.Count -gt 0) { return $r.value[0] }
  } catch { }

  return $null
}

function Get-LastInteractiveSignInV1 {
  param([string] $userId)

  $url = "https://graph.microsoft.com/v1.0/auditLogs/signIns?`$filter=userId eq '$userId'&`$orderby=createdDateTime desc&`$top=1"
  $attempts = 0
  while ($attempts -lt 4) {
    try {
      $resp = Invoke-RestMethod -Method GET -Uri $url -Headers $auth -ErrorAction Stop
      if ($resp.value.Count -gt 0) { return $resp.value[0] }
      return $null
    } catch {
      $attempts++
      $status = $_.Exception.Response.StatusCode.value__
      if ($status -eq 429) {
        $retryAfter = $_.Exception.Response.Headers["Retry-After"]
        if (-not $retryAfter) { $retryAfter = 5 }
        Write-Warning "Throttled (429). Waiting $retryAfter s then retry ($attempts/3)..."
        Start-Sleep -Seconds $retryAfter
        continue
      } else {
        Write-Warning "v1.0 signIns query failed: $($_.Exception.Message)"
        return $null
      }
    }
  }
  return $null
}

# ---------- RESOLVE USER ----------
$user = Resolve-User -email $targetEmail
if (-not $user) {
  Write-Warning "Could not resolve a user for '$targetEmail' in your tenant."
  return
}
Write-Host "Resolved user:`n  Name: $($user.displayName)`n  UPN : $($user.userPrincipalName)`n  Type: $($user.userType)`n  ID  : $($user.id)`n" -ForegroundColor Cyan

# ---------- DIRECT MEMBERSHIP ----------
$directHits = @()
foreach ($gid in $groupIds) {
  $uri = "https://graph.microsoft.com/v1.0/groups/$gid/members?`$select=id,userPrincipalName&`$top=999"
  do {
    try {
      $resp = Invoke-Graph $uri
    } catch {
      Write-Warning "Error querying group $gid members: $($_.Exception.Message)"
      break
    }
    if ($resp.value | Where-Object { $_.id -eq $user.id }) {
      $directHits += $gid
      break
    }
    $uri = $resp.'@odata.nextLink'
  } while ($uri)
}

if ($directHits.Count) {
  Write-Host "DIRECT membership found in group(s): $($directHits -join ', ')" -ForegroundColor Green
} else {
  Write-Host "No DIRECT membership found in provided groups." -ForegroundColor Yellow
}

# ---------- TRANSITIVE MEMBERSHIP (nested groups) ----------
try {
  $tm = Invoke-Graph "https://graph.microsoft.com/v1.0/users/$($user.id)/transitiveMemberOf?`$select=id,displayName"
  $tmIds = $tm.value.id
  $transitiveHits = $groupIds | Where-Object { $tmIds -contains $_ }
  if ($transitiveHits) {
    Write-Host "TRANSITIVE membership found in group(s): $($transitiveHits -join ', ')" -ForegroundColor Green
  } else {
    Write-Host "No TRANSITIVE membership found in provided groups." -ForegroundColor Yellow
  }
} catch {
  Write-Warning "Error querying transitive membership: $($_.Exception.Message)"
}

# ---------- LAST SIGN-IN ----------
# 1) v1.0 auditLogs/signIns (interactive)
$siV1 = Get-LastInteractiveSignInV1 -userId $user.id
if ($siV1) {
  Write-Host "`nLast sign-in (v1.0 signIns):" -ForegroundColor Cyan
  Write-Host "  Time       : $($siV1.createdDateTime)"
  Write-Host "  IP         : $($siV1.ipAddress)"
  Write-Host "  App        : $($siV1.appDisplayName)"
  Write-Host "  StatusCode : $($siV1.status.errorCode)"
} else {
  Write-Host "`nNo records from v1.0 signIns."
}

# 2) signInActivity rollup on the user
try {
  $urlAct = "https://graph.microsoft.com/v1.0/users/$($user.id)?`$select=displayName,userPrincipalName,signInActivity"
  $act = Invoke-Graph $urlAct
  if ($act.signInActivity) {
    Write-Host "`nsignInActivity (rollup on user):" -ForegroundColor Cyan
    Write-Host "  lastSignInDateTime              : $($act.signInActivity.lastSignInDateTime)"
    Write-Host "  lastNonInteractiveSignInDateTime: $($act.signInActivity.lastNonInteractiveSignInDateTime)"
    Write-Host "  lastSuccessfulSignInDateTime    : $($act.signInActivity.lastSuccessfulSignInDateTime)"
    Write-Host "  lastSignInRequestId             : $($act.signInActivity.lastSignInRequestId)"
  } else {
    Write-Host "`nNo signInActivity available for this user."
  }
} catch {
  Write-Warning "signInActivity query failed: $($_.Exception.Message)"
}
