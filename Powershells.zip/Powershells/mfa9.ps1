$tenantId     = "9a5cacd0-2bef-4dd7-ac5c-7ebe1f54f495"
$clientId     = "28d48667-10ad-4563-93c3-499438dafbab"
$clientSecret = "iUb8Q~v6_N_C41FVhk7kIarErqlH7ulV4FVWCbVq"
$groupId = "0ef5dc15-0d02-4f8c-8ca6-72bcff871524"

$groupId = "0ef5dc15-0d02-4f8c-8ca6-72bcff871524"

# ---- token ----
$tok = Invoke-RestMethod -Method POST -Uri "https://login.microsoftonline.com/$tenantId/oauth2/v2.0/token" -Body @{
  client_id=$clientId; client_secret=$clientSecret; grant_type="client_credentials"; scope="https://graph.microsoft.com/.default"
}
$token = $tok.access_token

# ---- decode roles ----
$payload = $token.Split('.')[1].Replace('-', '+').Replace('_', '/')
switch ($payload.Length % 4) { 2 { $payload += '==' } 3 { $payload += '=' } }
$claims = ([Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($payload)) | ConvertFrom-Json)

"=== ROLES IN TOKEN ==="
$claims.roles | ForEach-Object { " - $_" }

if ($claims.roles -notcontains "Reports.Read.All") {
  "`n!!! Reports.Read.All is NOT in the token roles. The report will not return data. !!!"
}

$headers = @{ Authorization = "Bearer $token" }

# ---- pull 1 user from the group (top 1 just for testing) ----
$u = (Invoke-RestMethod -Headers $headers -Uri "https://graph.microsoft.com/beta/groups/$groupId/members/microsoft.graph.user?`$top=1&`$select=id,displayName,userPrincipalName").value[0]
"`n=== TEST USER ==="
$u | Select-Object displayName, userPrincipalName, id | Format-List

# ---- call report endpoint WITHOUT Accept header (often returns CSV) ----
$repUri = "https://graph.microsoft.com/beta/reports/authenticationMethods/userRegistrationDetails"
"`n=== REPORT CALL (no Accept header) ==="
try {
  $raw = Invoke-WebRequest -Headers $headers -Uri $repUri -Method GET
  "HTTP: $($raw.StatusCode)"
  "Content-Type: $($raw.Headers['Content-Type'])"
  "First 200 chars:"
  ($raw.Content.Substring(0, [Math]::Min(200, $raw.Content.Length)))
} catch {
  "FAILED: $($_.Exception.Message)"
}

# ---- call report endpoint WITH Accept: application/json ----
"`n=== REPORT CALL (Accept: application/json) ==="
try {
  $h2 = @{ Authorization = "Bearer $token"; Accept = "application/json" }
  $json = Invoke-RestMethod -Headers $h2 -Uri $repUri -Method GET
  "Got JSON value count: $($json.value.Count)"
  if ($json.value.Count -gt 0) {
    "Sample row keys: " + (($json.value[0].psobject.Properties.Name) -join ", ")
  }
} catch {
  "FAILED: $($_.Exception.Message)"
}

# ---- if CSV, parse and lookup the test user ----
"`n=== CSV PARSE + LOOKUP USER ==="
try {
  $raw = Invoke-WebRequest -Headers $headers -Uri $repUri -Method GET
  $csvRows = $raw.Content | ConvertFrom-Csv
  $row = $csvRows | Where-Object { $_.id -eq $u.id } | Select-Object -First 1

  if ($null -eq $row) {
    "No row found in report for this userId (either report scope or permission issue)."
  } else {
    $row | Select-Object id, userPrincipalName, isMfaRegistered, mfaRegistrationStatus, defaultMfaMethod, methodsRegistered | Format-List
  }
} catch {
  "FAILED: $($_.Exception.Message)"
}